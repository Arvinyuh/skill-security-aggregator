"""
Skill Security Aggregator
综合安全评分聚合器
调用 Layer1、Layer2、Layer3 三个独立 Skill，计算最终安全评分，生成 DOCX 详细报告

输出格式:
  --text (默认)  终端文本报告
  --json          JSON 格式
  --docx          生成 DOCX 详细报告（含三层 Checklist）
"""

import os
import sys
import json
import re as _re
import subprocess
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from enum import Enum
from datetime import datetime

# ── python-docx 可选依赖 ─────────────────────────────────────────────────────
try:
    import docx
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches, Cm
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
    _HAS_DOCX = True
except ImportError:
    _HAS_DOCX = False


def _normalize_path(path_str: str) -> Path:
    """规范化路径，兼容 Windows/MSYS/Git Bash 路径格式"""
    p = path_str.replace('\\', '/')
    m = _re.match(r'^/([a-zA-Z])/(.*)$', p)
    if m:
        drive = m.group(1).upper()
        rest = m.group(2)
        return Path(f'{drive}:\\{rest.replace("/", os.sep)}')
    return Path(path_str)


# ══════════════════════════════════════════════════════════════════════════════
# 三层 Checklist 定义（当各层未返回 checklist 时使用默认项）
# ══════════════════════════════════════════════════════════════════════════════

DEFAULT_CHECKLISTS = {
    "layer1": [
        {"id": "L1-01", "item": "硬编码凭据检测（密码/Token/API Key）",      "category": "凭据泄露"},
        {"id": "L1-02", "item": "危险函数调用检测（eval/exec/os.system）",  "category": "代码执行"},
        {"id": "L1-03", "item": "网络通信检测（socket/requests/urllib）",    "category": "数据外泄"},
        {"id": "L1-04", "item": "文件系统访问检测（open/write/file）",      "category": "文件操作"},
        {"id": "L1-05", "item": "混淆代码检测（encode/encrypt/压缩）",      "category": "混淆规避"},
        {"id": "L1-06", "item": "环境变量滥用检测",                          "category": "权限提升"},
        {"id": "L1-07", "item": "子进程调用检测（subprocess/popen）",        "category": "代码执行"},
        {"id": "L1-08", "item": "动态导入检测（__import__/importlib）",      "category": "动态加载"},
    ],
    # Layer2 checklist 对应 SKILL.md 审查协议的四大危险类别
    # 每类检测：CRITICAL(-30) / HIGH(-20) / MEDIUM(-10) / LOW(-5)
    "layer2": [
        {"id": "L2-01", "item": "动态代码执行检测（eval/exec/base64/shell=True）",       "category": "代码执行"},
        {"id": "L2-02", "item": "凭证与记忆文件访问检测（~/.ssh/.aws/MEMORY.md等）",       "category": "凭据泄露"},
        {"id": "L2-03", "item": "外部网络请求检测（curl/wget/数据外泄）",                 "category": "数据外泄"},
        {"id": "L2-04", "item": "子进程与系统调用检测（subprocess/os.system/Popen）",      "category": "代码执行"},
        {"id": "L2-05", "item": "环境变量滥用检测（os.environ/getenv）",                   "category": "权限提升"},
        {"id": "L2-06", "item": "文件路径穿越检测（../、PathTraversal）",                  "category": "文件操作"},
        {"id": "L2-07", "item": "外部 AI API 调用检测（OpenAI/Gemini）",                   "category": "数据外泄"},
    ],
    "layer3": [
        {"id": "L3-01", "item": "敏感数据访问检测（密码/Token/私钥）",      "category": "数据泄露"},
        {"id": "L3-02", "item": "外部 API 调用检测（未授权通信）",           "category": "数据外泄"},
        {"id": "L3-03", "item": "RAG 知识库污染检测",                       "category": "数据投毒"},
        {"id": "L3-04", "item": "文件路径遍历检测",                          "category": "文件操作"},
        {"id": "L3-05", "item": "个人信息泄露检测（PII）",                   "category": "隐私违规"},
        {"id": "L3-06", "item": "跨 Skill 数据泄漏检测",                     "category": "横向移动"},
    ],
}


class RiskLevel(Enum):
    """风险等级"""
    SAFE     = "SAFE"
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"


# ══════════════════════════════════════════════════════════════════════════════
# Skill 路径配置
# ══════════════════════════════════════════════════════════════════════════════

SKILL_PATHS = {
    "layer1": Path(__file__).parent.parent.parent / "skill-layer1-regex-scan" / "scripts" / "regex_scanner.py",
    "layer2": Path(__file__).parent.parent.parent / "skill-layer2-prompt-eval" / "scripts" / "prompt_evaluator.py",
    "layer3": Path(__file__).parent.parent.parent / "skill-layer3-rag" / "scripts" / "rag_scanner.py",
}


@dataclass
class CheckItem:
    """单个检查项结果"""
    id: str
    item: str
    category: str
    status: str = "PASS"       # PASS / FAIL / WARN / MANUAL
    detail: str = ""
    evidence: str = ""


@dataclass
class LayerScore:
    """各层评分结果"""
    layer_name: str
    score: float
    weight: float
    details: Dict = field(default_factory=dict)
    raw_output: str = ""
    error: Optional[str] = None
    checklist: List[CheckItem] = field(default_factory=list)


@dataclass
class AggregatedResult:
    """聚合结果"""
    skill_name: str = ""
    skill_path: str = ""
    total_score: float = 100.0
    risk_level: RiskLevel = RiskLevel.SAFE
    recommendation: str = ""

    # 各层分数
    layer1_score: float = 100.0
    layer2_score: float = 100.0
    layer3_score: float = 100.0

    # 各层详情 + checklist
    layer1_details: Dict = field(default_factory=dict)
    layer2_details: Dict = field(default_factory=dict)
    layer3_details: Dict = field(default_factory=dict)
    layer1_checklist: List[CheckItem] = field(default_factory=list)
    layer2_checklist: List[CheckItem] = field(default_factory=list)
    layer3_checklist: List[CheckItem] = field(default_factory=list)

    # 原始输出
    layer1_raw: str = ""
    layer2_raw: str = ""
    layer3_raw: str = ""

    # 错误信息
    errors: List[str] = field(default_factory=list)

    # 元数据
    scan_time: str = ""
    execution_time: float = 0.0


def _parse_layer1_findings_from_text(output: str) -> Tuple[float, List[CheckItem], Dict]:
    """从 Layer1 文本输出中解析分数和 checklist

    处理格式:
      SECURITY SCORE: X/100
      KEY FINDINGS:
        🔴 [HIGH] 类别名 → 文件路径:行号 描述
    """
    # 提取分数
    score = 0.0
    m = _re.search(r'SECURITY\s*SCORE:\s*(\d+(?:\.\d+)?)\s*/\s*100', output, _re.IGNORECASE)
    if m:
        score = float(m.group(1))
    else:
        # fallback: 提取第一个 SCORE 行
        m2 = _re.search(r'SCORE:\s*(\d+(?:\.\d+)?)\s*/\s*100', output, _re.IGNORECASE)
        if m2:
            score = float(m2.group(1))

    # 解析 KEY FINDINGS
    findings: List[Dict] = []
    # 匹配 🔴 / 🟠 / 🟡 + [LEVEL] + 类别 → path:line 描述
    pattern = r'([🔴🟠🟡⚫])\s*\[(\w+)\]\s*([^\n→]+?)(?:→|\s*$)[\s\S]*?(?:^\s*(.+?)(?:\n|$))?'
    # 更简单：提取所有 🔴/🟠 行
    for line in output.splitlines():
        level = None
        if '🔴' in line or '[CRITICAL]' in line.upper():
            level = 'CRITICAL'
        elif '[HIGH]' in line.upper():
            level = 'HIGH'
        elif '🟡' in line or '[MEDIUM]' in line.upper():
            level = 'MEDIUM'
        elif '🟢' in line or '[LOW]' in line.upper():
            level = 'LOW'
        if level:
            # 提取类别（[]内的词）
            cat_m = _re.search(r'\[(\w+)\]', line)
            category = cat_m.group(1) if cat_m else level
            # 提取文件路径
            path_m = _re.search(r'([^:\n]+):(\d+)', line)
            path = f"{path_m.group(1)}:{path_m.group(2)}" if path_m else "SKILL.md"
            # 提取描述
            desc = line.strip()
            findings.append({"level": level, "category": category, "path": path, "desc": desc})

    # 根据发现构建 checklist
    defaults = DEFAULT_CHECKLISTS.get("layer1", [])
    checklist: List[CheckItem] = []

    # 分类发现到各检查项
    category_map = {
        "凭据泄露":   [f for f in findings if f["category"] in ("凭据泄露", "CRITICAL")],
        "代码执行":   [f for f in findings if f["category"] in ("代码执行", "HIGH")],
        "数据外泄":   [f for f in findings if f["category"] in ("数据外泄", "HIGH")],
        "文件操作":   [f for f in findings if f["category"] in ("文件操作", "HIGH")],
        "混淆规避":   [f for f in findings if f["category"] in ("混淆规避", "MEDIUM")],
        "权限提升":   [f for f in findings if f["category"] in ("权限提升", "HIGH")],
        "子进程":     [f for f in findings if f["category"] in ("子进程", "HIGH")],
        "动态加载":   [f for f in findings if f["category"] in ("动态加载", "MEDIUM")],
    }

    # 也考虑 LEVEL 分类
    level_map = {
        "CRITICAL": [f for f in findings if f["level"] == "CRITICAL"],
        "HIGH":     [f for f in findings if f["level"] == "HIGH"],
        "MEDIUM":   [f for f in findings if f["level"] == "MEDIUM"],
    }

    for ci in defaults:
        related = []
        # 先按 category 找
        if ci["category"] in category_map:
            related = category_map[ci["category"]]
        # 找不到就用 level 推断（权限提升 = sudo → HIGH = FAIL）
        if not related and ci["category"] == "权限提升":
            related = level_map.get("HIGH", [])
        # 合并 detail
        if related:
            details_parts = [f"{f['path']}: {f['desc'][:80]}" for f in related[:3]]
            detail = "; ".join(details_parts)
            status = "FAIL"
        else:
            detail = f"自动推断（层评分={score:.0f}）"
            status = "PASS" if score >= 70 else ("WARN" if score >= 40 else "FAIL")
        checklist.append(CheckItem(**ci, status=status, detail=detail))

    # 提取扫描统计
    stats = {}
    m_files = _re.search(r'Files\s+Scanned:\s*(\d+)', output)
    m_lines = _re.search(r'Lines\s+Scanned:\s*(\d+)', output)
    m_total = _re.search(r'Total\s+Findings:\s*(\d+)', output)
    if m_files:  stats['files_scanned'] = int(m_files.group(1))
    if m_lines:  stats['lines_scanned'] = int(m_lines.group(1))
    if m_total: stats['total_findings'] = int(m_total.group(1))

    return score, checklist, {
        "score": score,
        "findings_count": len(findings),
        "findings": findings,          # 保留全部，不截断
        "scan_stats": stats,
    }


def _normalize_layer1_json(jd: Dict) -> Dict:
    """将 Layer1 scanner JSON 统一转换为内部 details 格式

    scanner JSON:
      {"findings": [{"category": str, "severity": str, "file": str, "line": int, ...}], ...}
    内部格式:
      {"level": str, "category": str, "path": str, "desc": str, "evidence": str}
    """
    findings = jd.get("findings", [])
    stats = jd.get("statistics", {})
    norm = []
    for f in findings:
        severity = f.get("severity", "HIGH") or "HIGH"
        level = severity.upper()
        category = f.get("category", level)
        fname = f.get("file", "SKILL.md")
        short = fname.rsplit(os.sep, 1)[-1] if os.sep in fname else fname
        line = f.get("line", 0)
        path = f"{short}:{line}"
        match = f.get("match", "")
        norm.append({
            "level": level, "category": category,
            "path": path, "desc": f"{category} — {match[:100]}", "evidence": match[:200],
        })
    return {
        "score": jd.get("score", 0.0),
        "findings_count": len(norm),
        "findings": norm,
        "scan_stats": {
            "files_scanned": stats.get("files_scanned", 0),
            "lines_scanned": stats.get("lines_scanned", 0),
            "total_findings": stats.get("total_findings", len(norm)),
        },
        "risk_distribution": jd.get("risk_distribution", {}),
    }


def _parse_layer3_findings_from_text(output: str) -> Tuple[float, List[CheckItem], Dict]:
    """从 Layer3 RAG scanner 文本输出中解析分数和 TOP MATCHES

    处理格式:
      TOP MATCHES:
        🚨 name (LABEL, similarity: X.XX)
           Severity: ...
           Preview: ...
      SECURITY SCORE: X/100
      MATCHES: N malware, N benign

    也支持纯 JSON 格式（无代码块包裹）:
      {"score": 83.4, ...}
    """
    score = 0.0

    # ── 优先：从纯 JSON 格式中提取 score ──────────────────────────────────────
    # 当 print 语句改到 stderr 后，stdout 只剩纯 JSON
    json_match = _re.search(r'"score"\s*:\s*([\d.]+)', output)
    if json_match:
        score = float(json_match.group(1))
        return score, [], {"score": score, "note": "从纯 JSON 提取"}

    # ── 回退：从格式化文本中提取 ──────────────────────────────────────────────
    m = _re.search(r'SECURITY\s*SCORE:\s*(\d+(?:\.\d+)?)\s*/\s*100', output, _re.IGNORECASE)
    if m:
        score = float(m.group(1))

    # 解析 TOP MATCHES
    matches: List[Dict] = []
    match_blocks = _re.split(r'\n(?=\s{2,}🚨|\s{2,}✅|\s{2,}🟢)', output)
    for block in match_blocks:
        # 提取: 🚨 name (LABEL, similarity: X.XX)
        header_m = _re.search(r'[🚨✅🟢]\s+([^\s(]+)\s+\(([^,]+),\s*similarity:\s*([\d.]+)\)', block)
        if not header_m:
            continue
        name = header_m.group(1)
        label = header_m.group(2)
        similarity = float(header_m.group(3))
        severity_m = _re.search(r'Severity:\s*(\S+)', block)
        preview_m = _re.search(r'Preview:\s*(.+)', block)
        severity = severity_m.group(1) if severity_m else "UNKNOWN"
        preview = preview_m.group(1).strip()[:200] if preview_m else ""
        matches.append({
            "name": name, "label": label, "similarity": similarity,
            "severity": severity, "preview": preview,
        })

    # 解析统计行
    match_count_m = _re.search(r'MATCHES:\s*(\d+)\s+malware,\s*(\d+)\s+benign', output)
    kb_m = _re.search(r'Knowledge\s+Base\s+Entries:\s*(\d+)', output)
    match_count = {"malware": 0, "benign": 0}
    if match_count_m:
        match_count = {"malware": int(match_count_m.group(1)), "benign": int(match_count_m.group(2))}

    return score, [], {
        "score": score,
        "matches_count": match_count,
        "matches": matches,
        "knowledge_base_entries": int(kb_m.group(1)) if kb_m else 0,
    }


def _manual_evaluate_layer2(skill_path: Path) -> Tuple[float, List[CheckItem], Dict]:
    """手动评估 Layer2 — 基于 skill-layer2-prompt-eval/SKILL.md 审查协议

    协议要求：读取目标 Skill 所有文件，检查危险信号，按扣分制计算评分：
      CRITICAL: -30分  HIGH: -20分  MEDIUM: -10分  LOW: -5分
      最终得分 = 100 - Σ扣分

    危险信号列表（来自 SKILL.md 步骤2）：
      CRITICAL: curl/wget/eval/exec/base64.decode/shell=True/访问 MEMORY.md/USER.md/SOUL.md
      HIGH:    subprocess/os.environ/读取 ~/.ssh ~/.aws ~/.config/子进程执行
      MEDIUM:  外部API调用(OpenAI等)/文件路径操作
      LOW:     日志输出/代码注释
    """
    if not skill_path.exists():
        return 0.0, [], {}

    # ── 读取目标 Skill 所有文件 ──────────────────────────────────────────────
    all_text: List[Tuple[str, str]] = []  # (filename, content)
    skill_files = list(skill_path.rglob("*"))
    for f in skill_files:
        if f.is_file() and not f.name.startswith('.'):
            try:
                content = f.read_text(encoding='utf-8', errors='ignore')
                rel = str(f.relative_to(skill_path))
                all_text.append((rel, content))
            except Exception:
                pass

    combined = "\n".join(content for _, content in all_text)

    # ── 危险信号检测 ────────────────────────────────────────────────────────
    deductions: List[Dict] = []  # {"level": str, "label": str, "file": str, "detail": str}

    # CRITICAL (-30)
    crit_patterns = [
        (r'eval\s*\(',                      "eval() 动态代码执行"),
        (r'exec\s*\(',                      "exec() 动态代码执行"),
        (r'base64\.(b64decode|decode)\s*\(', "base64 解码操作"),
        (r'shell\s*=\s*True',               "subprocess shell=True"),
        (r'curl\s+.*https?://',              "curl 外部请求"),
        (r'wget\s+.*https?://',              "wget 外部请求"),
        (r'(requests?|fetch)\s*\(.*https?://', "HTTP 请求到外部服务器"),
        (r'MEMORY\.md|USER\.md|SOUL\.md|IDENTITY\.md', "访问 Agent 记忆文件"),
    ]
    for pat, label in crit_patterns:
        for fname, content in all_text:
            hits = list(_re.finditer(pat, content, _re.IGNORECASE))
            if hits:
                for h in hits[:3]:  # 每文件最多3条
                    line_num = content[:h.start()].count('\n') + 1
                    snippet = content[max(0, h.start()-20):h.end()+40].replace('\n', ' ').strip()
                    deductions.append({
                        "level": "CRITICAL", "label": label,
                        "file": f"{fname}:{line_num}",
                        "detail": snippet[:120], "count": len(hits)
                    })

    # HIGH (-20)
    high_patterns = [
        (r'subprocess\.',                    "subprocess 模块调用"),
        (r'os\.system\s*\(',                 "os.system 调用"),
        (r'os\.popen\s*\(',                 "os.popen 调用"),
        (r'\.ssh/|/\.ssh\s',                 "SSH 目录访问"),
        (r'\.aws/|/\.aws\s',                 "AWS 凭证目录访问"),
        (r'\.config/|/\.config\s',            "配置目录访问"),
        (r'os\.environ',                     "环境变量读取"),
        (r'getenv\s*\(',                     "getenv 环境变量读取"),
        (r'Popen\s*\(',                      "子进程 Popen"),
    ]
    for pat, label in high_patterns:
        for fname, content in all_text:
            hits = list(_re.finditer(pat, content, _re.IGNORECASE))
            if hits:
                for h in hits[:3]:
                    line_num = content[:h.start()].count('\n') + 1
                    snippet = content[max(0, h.start()-20):h.end()+40].replace('\n', ' ').strip()
                    deductions.append({
                        "level": "HIGH", "label": label,
                        "file": f"{fname}:{line_num}",
                        "detail": snippet[:120], "count": len(hits)
                    })

    # MEDIUM (-10)
    med_patterns = [
        (r'openai|gemini|anthropic|azure_openai',  "外部 AI API 调用"),
        (r'os\.path\.join.*\.\./',             "文件路径穿越（../）"),
        (r'PathTraversal|directory_traversal',  "路径遍历关键词"),
        (r'\.\./|\.\.\\\\',                    "路径穿越符"),
    ]
    for pat, label in med_patterns:
        for fname, content in all_text:
            hits = list(_re.finditer(pat, content, _re.IGNORECASE))
            if hits:
                for h in hits[:2]:
                    line_num = content[:h.start()].count('\n') + 1
                    snippet = content[max(0, h.start()-20):h.end()+40].replace('\n', ' ').strip()
                    deductions.append({
                        "level": "MEDIUM", "label": label,
                        "file": f"{fname}:{line_num}",
                        "detail": snippet[:120], "count": len(hits)
                    })

    # LOW (-5)
    low_patterns = [
        (r'console\.(log|error|warn)',        "console 日志输出"),
        (r'print\s*\(',                      "print 调试输出"),
        (r'#\s*(TODO|FIXME|HACK|XXX|BUG)',    "代码注释标记"),
    ]
    for pat, label in low_patterns:
        for fname, content in all_text:
            hits = list(_re.finditer(pat, content, _re.IGNORECASE))
            if hits:
                for h in hits[:2]:
                    line_num = content[:h.start()].count('\n') + 1
                    snippet = content[max(0, h.start()-20):h.end()+40].replace('\n', ' ').strip()
                    deductions.append({
                        "level": "LOW", "label": label,
                        "file": f"{fname}:{line_num}",
                        "detail": snippet[:120], "count": len(hits)
                    })

    # ── 计算扣分和总分 ──────────────────────────────────────────────────────
    deduction_weights = {"CRITICAL": 30, "HIGH": 20, "MEDIUM": 10, "LOW": 5}
    total_deduction = sum(deduction_weights[d["level"]] for d in deductions)
    # 合并同一类型的多个发现，只扣一次
    ded_type: Dict[str, int] = {}
    for d in deductions:
        key = f"{d['level']}:{d['label']}"
        if key not in ded_type:
            ded_type[key] = deduction_weights[d["level"]]
    total_deduction = sum(ded_type.values())

    score = max(0.0, 100.0 - total_deduction)

    # ── 构建 Checklist ──────────────────────────────────────────────────────
    defaults = DEFAULT_CHECKLISTS.get("layer2", [])
    checklist: List[CheckItem] = []
    for ci in defaults:
        ci_id = ci["id"]
        ci_label = ci["item"]
        # 匹配扣分项到检查项
        matched = [d for d in deductions if _match_to_check(ci_id, d["label"])]
        if matched:
            worst = max(matched, key=lambda x: deduction_weights[x["level"]])
            status = "FAIL"
            detail = f"{worst['level']} {worst['label']} ({worst['file']})"
            evidence = worst["detail"]
        else:
            status = "PASS"
            detail = "未发现该类风险"
            evidence = ""
        checklist.append(CheckItem(**ci, status=status, detail=detail, evidence=evidence))

    findings = {
        "deductions": deductions,
        "deduction_by_type": ded_type,
        "total_deduction": total_deduction,
        "files_scanned": len(all_text),
    }
    return score, checklist, findings


def _match_to_check(check_id: str, ded_label: str) -> bool:
    """判断扣分项（ded_label）是否属于某检查项（check_id）
    映射关系：扣分 label → 对应 L2 检查项
    """
    mapping = {
        "L2-01": ["eval", "exec", "base64", "shell=True", "动态代码"],
        "L2-02": [".ssh", ".aws", ".config", "MEMORY", "USER", "SOUL", "IDENTITY", "凭证"],
        "L2-03": ["curl", "wget", "HTTP", "外部请求", "数据外泄"],
        "L2-04": ["subprocess", "Popen", "os.system", "os.popen", "子进程", "系统调用"],
        "L2-05": ["environ", "getenv", "环境变量"],
        "L2-06": ["路径穿越", "穿越符", "PathTraversal", "../", "..\\"],
        "L2-07": ["OpenAI", "Gemini", "Anthropic", "外部 AI", "API 调用"],
    }
    keywords = mapping.get(check_id, [])
    dl = ded_label.lower()
    return any(kw.lower() in dl for kw in keywords)


def _parse_checklist_from_json(json_data: Dict, layer_key: str) -> List[CheckItem]:
    """从各层 JSON 输出中解析 checklist；若无非默认项，返回默认 checklist（全部 PASS）"""
    items: List[CheckItem] = []
    raw_items = json_data.get("checklist", [])
    if raw_items:
        for ci in raw_items:
            items.append(CheckItem(
                id=ci.get("id", ""),
                item=ci.get("item", ci.get("name", "")),
                category=ci.get("category", ""),
                status=ci.get("status", "PASS"),
                detail=ci.get("detail", ""),
                evidence=ci.get("evidence", ""),
            ))
        return items

    # 无 checklist 返回时，用默认项 + 根据 score 推断状态
    score = float(json_data.get("score", 100.0))
    defaults = DEFAULT_CHECKLISTS.get(layer_key, [])
    for ci in defaults:
        status = "PASS" if score >= 70 else ("WARN" if score >= 40 else "FAIL")
        items.append(CheckItem(**ci, status=status, detail=f"自动推断（层评分={score:.0f}）"))
    return items


class SecurityAggregator:
    """安全评分聚合器"""

    def __init__(self):
        self.weights = {
            "layer1": 0.35,
            "layer2": 0.35,
            "layer3": 0.30,
        }

    def _get_python_executable(self) -> str:
        return sys.executable or "python"

    def _run_skill(self, skill_path: Path, skill_dir: Path,
                   args: List[str] = None,
                   stderr_output: bool = False) -> Tuple[str, Optional[str]]:
        if not skill_path.exists():
            return "", f"Skill script not found: {skill_path}"
        cmd = [self._get_python_executable(), str(skill_path)]
        if args:
            cmd.extend(args)
        try:
            if stderr_output:
                # 分离 stdout/stderr：stdout=JSON，stderr=进度消息（不污染 JSON）
                result = subprocess.run(
                    cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                    timeout=120, encoding='utf-8', errors='ignore',
                    cwd=str(skill_dir)
                )
            else:
                result = subprocess.run(
                    cmd, capture_output=True, text=True,
                    timeout=120, encoding='utf-8', errors='ignore',
                    cwd=str(skill_dir)
                )
            if result.returncode in [0, 1, 2]:
                return result.stdout, None
            return result.stdout, f"Exit code: {result.returncode}"
        except subprocess.TimeoutExpired:
            return "", "Timeout after 120 seconds"
        except Exception as e:
            return "", str(e)

    def _parse_json_output(self, output: str) -> Optional[Dict]:
        try:
            return json.loads(output)
        except json.JSONDecodeError:
            match = _re.search(r'```json\s*(.*?)\s*```', output, _re.DOTALL)
            if match:
                try:
                    return json.loads(match.group(1))
                except Exception:
                    pass
        return None

    def _parse_score_from_text(self, output: str, default: float = 100.0) -> float:
        patterns = [
            r'SCORE:\s*(\d+(?:\.\d+)?)\s*/\s*100',
            r'Score:\s*(\d+(?:\.\d+)?)\s*/\s*100',
            r'([\d.]+)\s*/\s*100',
        ]
        for p in patterns:
            m = _re.search(p, output, _re.IGNORECASE)
            if m:
                return float(m.group(1))
        return default

    # ── 核心聚合 ─────────────────────────────────────────────────────────────
    def aggregate(self, skill_path: Path, verbose: bool = False) -> AggregatedResult:
        import time
        start_time = time.time()
        result = AggregatedResult(
            skill_name=skill_path.name,
            skill_path=str(skill_path),
            scan_time=datetime.now().isoformat()
        )

        if not skill_path.exists():
            normalized = _normalize_path(str(skill_path))
            if normalized.exists():
                skill_path = normalized
            result.errors.append(f"Skill path not found: {skill_path}")
            return result

        # ── Layer 1 ───────────────────────────────────────────────────────────
        if verbose:
            print("Running Layer1: Regex Scanner...")
        l1_path = SKILL_PATHS["layer1"]
        if l1_path.exists():
            # 使用 --json 获取完整发现列表（避免被 [:10] 截断）
            output, error = self._run_skill(l1_path, skill_path.parent.parent,
                                           [str(skill_path), "--json"])
            result.layer1_raw = output
            if error:
                result.errors.append(f"Layer1 error: {error}")
                result.layer1_score = 50.0
                result.layer1_checklist = [
                    CheckItem(**ci, status="MANUAL", detail="Layer1 执行失败，需人工审查")
                    for ci in DEFAULT_CHECKLISTS["layer1"]
                ]
            else:
                jd = self._parse_json_output(output)
                if jd:
                    result.layer1_score = float(jd.get('score', 100.0))
                    # 统一转换为内部格式，确保 DOCX 可用
                    details = _normalize_layer1_json(jd)
                    result.layer1_details = details
                    result.layer1_checklist = _parse_checklist_from_json(details, "layer1")
                else:
                    # JSON 解析失败，回退到文本解析
                    score, checklist, details = _parse_layer1_findings_from_text(output)
                    result.layer1_score = score
                    result.layer1_details = details
                    result.layer1_checklist = checklist
        else:
            result.errors.append(f"Layer1 not found: {l1_path}")
            result.layer1_score = 50.0
            result.layer1_checklist = [
                CheckItem(**ci, status="MANUAL", detail="Layer1 脚本不存在")
                for ci in DEFAULT_CHECKLISTS["layer1"]
            ]

        # ── Layer 2 ───────────────────────────────────────────────────────────
        if verbose:
            print("Running Layer2: Prompt Evaluator...")
        l2_path = SKILL_PATHS["layer2"]
        if l2_path.exists():
            output, error = self._run_skill(l2_path, skill_path.parent.parent, [str(skill_path)])
            result.layer2_raw = output
            if error:
                result.errors.append(f"Layer2 error: {error}")
                result.layer2_score = 50.0
                result.layer2_checklist = [
                    CheckItem(**ci, status="MANUAL", detail="Layer2 执行失败，需人工评估")
                    for ci in DEFAULT_CHECKLISTS["layer2"]
                ]
            else:
                jd = self._parse_json_output(output)
                if jd:
                    result.layer2_score = float(jd.get('score', 100.0))
                    result.layer2_details = jd
                    result.layer2_checklist = _parse_checklist_from_json(jd, "layer2")
                else:
                    result.layer2_score = self._parse_score_from_text(output)
                    result.layer2_checklist = [
                        CheckItem(**ci, status="PASS", detail="Prompt 评估未返回结构化数据")
                        for ci in DEFAULT_CHECKLISTS["layer2"]
                    ]
        else:
            # 纯 SKILL.md 模式：按 Layer2 协议对目标 Skill 做手动评估
            score, checklist, details = _manual_evaluate_layer2(skill_path)
            result.layer2_score = score
            result.layer2_checklist = checklist
            result.layer2_details = details
            deductions = details.get("deductions", [])
            files_scanned = details.get("files_scanned", 0)
            if deductions:
                result.errors.append(
                    f"Layer2 手动评估: 扫描 {files_scanned} 个文件，"
                    f"发现 {len(deductions)} 类风险，扣 {details.get('total_deduction', 0)} 分，得分 {score:.0f}"
                )
            else:
                result.errors.append(f"Layer2: 纯 SKILL.md 模式，扫描 {files_scanned} 个文件，未发现风险")

        # ── Layer 3 ───────────────────────────────────────────────────────────
        if verbose:
            print("Running Layer3: RAG Scanner...")
        l3_path = SKILL_PATHS["layer3"]
        if l3_path.exists():
            # 使用 --json 获取干净 JSON；progress 消息已改到 stderr，分离捕获
            output, error = self._run_skill(l3_path, skill_path.parent.parent,
                                           [str(skill_path), "--json"],
                                           stderr_output=True)
            result.layer3_raw = output
            if error:
                result.errors.append(f"Layer3 error: {error}")
                result.layer3_score = 50.0
                result.layer3_checklist = [
                    CheckItem(**ci, status="MANUAL", detail="Layer3 执行失败，需人工审查")
                    for ci in DEFAULT_CHECKLISTS["layer3"]
                ]
            else:
                jd = self._parse_json_output(output)
                if jd:
                    result.layer3_score = float(jd.get('score', 100.0))
                    result.layer3_details = jd
                    result.layer3_checklist = _parse_checklist_from_json(jd, "layer3")
                else:
                    # 文本模式：解析 RAG scanner 输出
                    score, _, details = _parse_layer3_findings_from_text(output)
                    result.layer3_score = score
                    result.layer3_details = details
                    result.layer3_checklist = [
                        CheckItem(**ci, status="PASS", detail="RAG 扫描通过")
                        for ci in DEFAULT_CHECKLISTS["layer3"]
                    ]
        else:
            result.errors.append(f"Layer3 not found: {l3_path}")
            result.layer3_score = 50.0
            result.layer3_checklist = [
                CheckItem(**ci, status="MANUAL", detail="Layer3 脚本不存在")
                for ci in DEFAULT_CHECKLISTS["layer3"]
            ]

        # ── 计算总分 ──────────────────────────────────────────────────────────
        result.total_score = (
            result.layer1_score * self.weights["layer1"] +
            result.layer2_score * self.weights["layer2"] +
            result.layer3_score * self.weights["layer3"]
        )
        result.risk_level, result.recommendation = self._get_risk_level(result.total_score)
        result.execution_time = time.time() - start_time
        return result

    def _get_risk_level(self, score: float) -> Tuple[RiskLevel, str]:
        if score >= 86:
            return RiskLevel.SAFE,     "安全，可安装"
        elif score >= 71:
            return RiskLevel.LOW,      "低风险，建议审查后安装"
        elif score >= 51:
            return RiskLevel.MEDIUM,   "中等风险，需要人工审查"
        elif score >= 31:
            return RiskLevel.HIGH,     "高风险，建议不安装"
        else:
            return RiskLevel.CRITICAL, "危险，拒绝安装"

    # ═══════════════════════════════════════════════════════════════════════
    #  文本报告
    # ═══════════════════════════════════════════════════════════════════════
    def get_report(self, result: AggregatedResult) -> str:
        risk_emoji = {
            RiskLevel.SAFE:     "✅",
            RiskLevel.LOW:      "🟢",
            RiskLevel.MEDIUM:   "🟡",
            RiskLevel.HIGH:     "🔴",
            RiskLevel.CRITICAL: "🚨",
        }
        l1_c = result.layer1_score * self.weights["layer1"]
        l2_c = result.layer2_score * self.weights["layer2"]
        l3_c = result.layer3_score * self.weights["layer3"]

        lines = [
            "=" * 68,
            "         SKILL SECURITY AGGREGATED REPORT",
            "=" * 68,
            f"Skill:       {result.skill_name}",
            f"Path:        {result.skill_path}",
            f"Scanned:     {result.scan_time}",
            f"Execution:   {result.execution_time:.2f}s",
            "-" * 68,
            "",
            "LAYER SCORES:",
            "┌─────────────┬──────────┬────────┬──────────┐",
            "│ Layer       │ Score    │ Weight │ Contrib  │",
            "├─────────────┼──────────┼────────┼──────────┤",
            f"│ Layer1      │ {result.layer1_score:6.1f}/100 │ 35%   │ {l1_c:6.1f}    │",
            f"│ Layer2      │ {result.layer2_score:6.1f}/100 │ 35%   │ {l2_c:6.1f}    │",
            f"│ Layer3      │ {result.layer3_score:6.1f}/100 │ 30%   │ {l3_c:6.1f}    │",
            "└─────────────┴──────────┴────────┴──────────┘",
            "",
            "WEIGHTED CALCULATION:",
            f"  {result.layer1_score:.1f}×0.35 + {result.layer2_score:.1f}×0.35 + {result.layer3_score:.1f}×0.30 = {result.total_score:.2f}",
            "",
            "-" * 68,
        ]

        # Checklist 摘要
        for layer_name, checklist in [
            ("Layer1 - Regex Scan",  result.layer1_checklist),
            ("Layer2 - Prompt Eval", result.layer2_checklist),
            ("Layer3 - RAG Scan",    result.layer3_checklist),
        ]:
            pass_cnt = sum(1 for c in checklist if c.status == "PASS")
            fail_cnt = sum(1 for c in checklist if c.status == "FAIL")
            warn_cnt = sum(1 for c in checklist if c.status == "WARN")
            manual_cnt = sum(1 for c in checklist if c.status == "MANUAL")
            lines += [
                f"CHECKLIST: {layer_name}",
                f"  ✓ PASS: {pass_cnt}   ✗ FAIL: {fail_cnt}   ⚠ WARN: {warn_cnt}   ? MANUAL: {manual_cnt}",
                ""
            ]

        if result.errors:
            lines.append("ERRORS:")
            for e in result.errors:
                lines.append(f"  ⚠️  {e}")
            lines.append("")

        lines += [
            "=" * 68,
            f"FINAL SCORE: {result.total_score:.0f}/100",
            f"RISK LEVEL:  {risk_emoji.get(result.risk_level, '')} {result.risk_level.value}",
            f"RECOMMEND:  {result.recommendation}",
            "=" * 68,
        ]
        return "\n".join(lines)

    def get_json_report(self, result: AggregatedResult) -> str:
        def _ci_to_dict(ci: CheckItem):
            return {"id": ci.id, "item": ci.item, "category": ci.category,
                    "status": ci.status, "detail": ci.detail, "evidence": ci.evidence}

        data = {
            "skill": {"name": result.skill_name, "path": result.skill_path},
            "scan_time": result.scan_time,
            "execution_time": result.execution_time,
            "weights": self.weights,
            "scores": {
                "layer1": {"score": result.layer1_score, "weight": self.weights["layer1"],
                           "contribution": result.layer1_score * self.weights["layer1"]},
                "layer2": {"score": result.layer2_score, "weight": self.weights["layer2"],
                           "contribution": result.layer2_score * self.weights["layer2"]},
                "layer3": {"score": result.layer3_score, "weight": self.weights["layer3"],
                           "contribution": result.layer3_score * self.weights["layer3"]},
            },
            "total_score": result.total_score,
            "risk_level": result.risk_level.value,
            "recommendation": result.recommendation,
            "errors": result.errors,
            "checklists": {
                "layer1": [_ci_to_dict(c) for c in result.layer1_checklist],
                "layer2": [_ci_to_dict(c) for c in result.layer2_checklist],
                "layer3": [_ci_to_dict(c) for c in result.layer3_checklist],
            },
            "details": {
                "layer1": result.layer1_details,
                "layer2": result.layer2_details,
                "layer3": result.layer3_details,
            }
        }
        return json.dumps(data, indent=2, ensure_ascii=False)

    # ═══════════════════════════════════════════════════════════════════════
    #  DOCX 报告生成
    # ═══════════════════════════════════════════════════════════════════════
    # ═══════════════════════════════════════════════════════════════════════════════
    #  DOCX 报告生成 — 六段式结构
    #  ───────────────────────────────────────────────────────────────────────────
    #  标题: SKILL SECURITY ASSESSMENT REPORT [skill_name]
    #  第1块: Skill 简介（用途、适用场景）
    #  第2块: 总体安全评价总览（三层评分 + 总分）
    #  第3块: 详细的 Checklist（分层展示）
    #  第4块: 整体综合判定和建议
    #  第5块: 关键发现及安全分析
    #  第6块: 附录：原始输出
    # ═══════════════════════════════════════════════════════════════════════════════
    def get_docx_report(self, result: AggregatedResult, output_path: str) -> str:
        """
        生成 DOCX 详细报告（六段式结构）
        返回输出文件路径
        """
        if not _HAS_DOCX:
            raise RuntimeError(
                "python-docx 未安装，请运行: pip install python-docx"
            )

        doc = Document()

        # ── 样式定义 ─────────────────────────────────────────────────────────
        style = doc.styles['Normal']
        font = style.font
        font.name = 'Calibri'
        font.size = Pt(10.5)

        # ── 颜色辅助 ─────────────────────────────────────────────────────────
        def _rgb(r, g, b):
            return RGBColor(r, g, b)

        STATUS_COLOR = {
            "PASS":   _rgb(0, 140, 0),
            "FAIL":   _rgb(200, 0, 0),
            "WARN":   _rgb(230, 145, 0),
            "MANUAL": _rgb(80, 80, 80),
        }
        STATUS_ZH = {
            "PASS":   "✓ 通过",
            "FAIL":   "✗ 失败",
            "WARN":   "⚠ 警告",
            "MANUAL": "? 待人工",
        }
        RISK_COLOR = {
            RiskLevel.SAFE:     _rgb(0, 140, 0),
            RiskLevel.LOW:      _rgb(0, 180, 0),
            RiskLevel.MEDIUM:   _rgb(230, 145, 0),
            RiskLevel.HIGH:     _rgb(200, 0, 0),
            RiskLevel.CRITICAL: _rgb(140, 0, 0),
        }

        # ── 辅助：插入分割线段落 ─────────────────────────────────────────────
        def _clean_text(s: str) -> str:
            """移除 DOCX 不兼容的控制字符（保留换行用空格替代）"""
            return _re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', ' ', s)

        def _add_divider():
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(4)
            run = p.add_run("─" * 60)
            run.font.color.rgb = _rgb(180, 180, 180)
            run.font.size = Pt(8)
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(4)
            p.paragraph_format.space_after = Pt(4)
            run = p.add_run("─" * 60)
            run.font.color.rgb = _rgb(180, 180, 180)
            run.font.size = Pt(8)

        # ── 辅助：插入状态标记统计 ───────────────────────────────────────────
        def _add_stats_bar(checklist: List[CheckItem]):
            stats = {"PASS": 0, "FAIL": 0, "WARN": 0, "MANUAL": 0}
            for ci in checklist:
                stats[ci.status] = stats.get(ci.status, 0) + 1
            parts = []
            if stats["PASS"]:   parts.append(f"✓ 通过 {stats['PASS']}")
            if stats["FAIL"]:   parts.append(f"✗ 失败 {stats['FAIL']}")
            if stats["WARN"]:   parts.append(f"⚠ 警告 {stats['WARN']}")
            if stats["MANUAL"]: parts.append(f"? 待人工 {stats['MANUAL']}")
            p = doc.add_paragraph()
            run = p.add_run("  |  ".join(parts))
            run.font.size = Pt(9)
            run.font.color.rgb = _rgb(80, 80, 80)
            run.italic = True

        # ── 辅助：标准 Checklist 表格 ───────────────────────────────────────
        def _add_checklist_table(checklist: List[CheckItem]):
            if not checklist:
                p = doc.add_paragraph("（无检查项数据）")
                p.runs[0].font.color.rgb = _rgb(120, 120, 120)
                p.runs[0].italic = True
                return
            t = doc.add_table(rows=len(checklist)+1, cols=5)
            t.style = 'Table Grid'
            t.alignment = WD_TABLE_ALIGNMENT.LEFT
            hdr_cols = ["编号", "检查项", "类别", "结果", "说明"]
            col_widths = [Inches(0.6), Inches(2.8), Inches(0.9), Inches(0.7), Inches(2.5)]
            for j, (h, w) in enumerate(zip(hdr_cols, col_widths)):
                cell = t.rows[0].cells[j]
                cell.text = h
                cell.paragraphs[0].runs[0].bold = True
                cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
                cell.width = w
            for i, ci in enumerate(checklist, 1):
                row = t.rows[i]
                row.cells[0].text = ci.id
                row.cells[1].text = ci.item
                row.cells[2].text = ci.category
                # 结果：带颜色
                rc = row.cells[3]
                rc.text = ""
                pr = rc.paragraphs[0]
                rr = pr.add_run(STATUS_ZH.get(ci.status, ci.status))
                rr.font.color.rgb = STATUS_COLOR.get(ci.status, _rgb(0, 0, 0))
                rr.bold = True
                pr.alignment = WD_ALIGN_PARAGRAPH.CENTER
                rc.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
                # 说明
                detail_text = _clean_text(ci.detail or "")
                if ci.evidence:
                    detail_text = detail_text + " | " + _clean_text(ci.evidence) if detail_text else _clean_text(ci.evidence)
                row.cells[4].text = detail_text
                for cell in row.cells:
                    cell.vertical_alignment = WD_ALIGN_VERTICAL.TOP
            doc.add_paragraph()

        # ═══════════════════════════════════════════════════════════════════════
        #  封面标题
        # ═══════════════════════════════════════════════════════════════════════
        title_p = doc.add_heading('SKILL SECURITY', 0)
        title_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for run in title_p.runs:
            run.font.color.rgb = _rgb(30, 80, 160)

        subtitle_p = doc.add_heading('ASSESSMENT REPORT', 0)
        subtitle_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for run in subtitle_p.runs:
            run.font.color.rgb = _rgb(30, 80, 160)

        # Skill 名称（醒目大字）
        skill_name_p = doc.add_paragraph()
        skill_name_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        skill_name_p.paragraph_format.space_before = Pt(6)
        sn_run = skill_name_p.add_run(result.skill_name.upper())
        sn_run.bold = True
        sn_run.font.size = Pt(20)
        sn_run.font.color.rgb = _rgb(50, 50, 50)

        _add_divider()

        # 综合评分 + 风险等级（居中醒目）
        score_p = doc.add_paragraph()
        score_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        sc_run = score_p.add_run(f"综合评分  {result.total_score:.0f} / 100")
        sc_run.bold = True
        sc_run.font.size = Pt(24)
        sc_run.font.color.rgb = RISK_COLOR.get(result.risk_level, _rgb(0, 0, 0))

        level_p = doc.add_paragraph()
        level_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        lv_run = level_p.add_run(f"风险等级: {result.risk_level.value}  |  {result.recommendation}")
        lv_run.bold = True
        lv_run.font.size = Pt(13)
        lv_run.font.color.rgb = RISK_COLOR.get(result.risk_level, _rgb(0, 0, 0))

        _add_divider()

        # 元数据表
        meta_tbl = doc.add_table(rows=4, cols=2)
        meta_tbl.style = 'Table Grid'
        meta_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
        meta_data = [
            ("Skill 名称", result.skill_name),
            ("Skill 路径", result.skill_path),
            ("扫描时间", result.scan_time.replace('T', ' ')),
            ("执行耗时", f"{result.execution_time:.2f} 秒"),
        ]
        for i, (k, v) in enumerate(meta_data):
            meta_tbl.rows[i].cells[0].text = k
            meta_tbl.rows[i].cells[1].text = v
            meta_tbl.rows[i].cells[0].paragraphs[0].runs[0].bold = True
            meta_tbl.rows[i].cells[0].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.LEFT
            meta_tbl.rows[i].cells[1].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.LEFT

        doc.add_page_break()

        # ═══════════════════════════════════════════════════════════════════════
        #  第1块: Skill 简介
        # ═══════════════════════════════════════════════════════════════════════
        doc.add_heading('一、Skill 简介', 1)

        skill_intro = self._extract_skill_intro(result.skill_path)
        if skill_intro:
            for para_text in skill_intro:
                doc.add_paragraph(para_text)
        else:
            p = doc.add_paragraph(
                f"该 Skill 位于 {result.skill_path}，主要用于安全评估与代码审计场景。\n"
                "有关 Skill 的详细用途和适用场景，请参考其 SKILL.md 文件。"
            )
            p.runs[0].font.color.rgb = _rgb(100, 100, 100)
            p.runs[0].italic = True

        # ═══════════════════════════════════════════════════════════════════════
        #  第2块: 总体安全评价总览
        # ═══════════════════════════════════════════════════════════════════════
        doc.add_heading('二、总体安全评价总览', 1)

        # 评分贡献表
        l1_c = result.layer1_score * self.weights["layer1"]
        l2_c = result.layer2_score * self.weights["layer2"]
        l3_c = result.layer3_score * self.weights["layer3"]

        score_tbl = doc.add_table(rows=5, cols=5)
        score_tbl.style = 'Table Grid'
        score_tbl.alignment = WD_TABLE_ALIGNMENT.LEFT
        score_hdrs = ["层级", "检查内容", "分数", "权重", "加权贡献"]
        for j, h in enumerate(score_hdrs):
            cell = score_tbl.rows[0].cells[j]
            cell.text = h
            cell.paragraphs[0].runs[0].bold = True
            cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

        layer_info = [
            ("Layer 1", "正则表达式静态扫描",  result.layer1_score, "35%", l1_c),
            ("Layer 2", "代码安全与权限评估",   result.layer2_score, "35%", l2_c),
            ("Layer 3", "RAG 知识库语义扫描",   result.layer3_score, "30%", l3_c),
        ]
        for i, (ln, desc, sc, wt, ct) in enumerate(layer_info, 1):
            row = score_tbl.rows[i]
            row.cells[0].text = ln
            row.cells[1].text = desc
            row.cells[2].text = f"{sc:.1f} / 100"
            row.cells[3].text = wt
            row.cells[4].text = f"{ct:.2f}"
            for cell in row.cells[2:]:
                cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
            # 分数颜色标注
            sc_run = row.cells[2].paragraphs[0].runs[0]
            if sc >= 86:
                sc_run.font.color.rgb = _rgb(0, 140, 0)
            elif sc >= 71:
                sc_run.font.color.rgb = _rgb(0, 180, 0)
            elif sc >= 51:
                sc_run.font.color.rgb = _rgb(230, 145, 0)
            else:
                sc_run.font.color.rgb = _rgb(200, 0, 0)

        # 总分行
        tr = score_tbl.rows[4]
        tr.cells[0].text = "综合"
        tr.cells[0].paragraphs[0].runs[0].bold = True
        tr.cells[1].text = result.risk_level.value
        tr.cells[2].text = f"{result.total_score:.1f} / 100"
        tr.cells[3].text = "100%"
        tr.cells[4].text = f"{result.total_score:.2f}"
        for cell in tr.cells:
            for run in cell.paragraphs[0].runs:
                run.bold = True
            cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        # 综合分数颜色
        total_run = tr.cells[2].paragraphs[0].runs[0]
        total_run.font.color.rgb = RISK_COLOR.get(result.risk_level, _rgb(0, 0, 0))

        for row in score_tbl.rows:
            row.vertical_alignment = WD_ALIGN_VERTICAL.CENTER

        doc.add_paragraph()

        # 计算公式
        formula_p = doc.add_paragraph()
        formula_p.add_run("加权公式:  ").bold = True
        formula_p.add_run(
            f"Layer1 × 0.35 + Layer2 × 0.35 + Layer3 × 0.30 "
            f"= {result.layer1_score:.1f}×0.35 + {result.layer2_score:.1f}×0.35 + {result.layer3_score:.1f}×0.30 "
            f"= {result.total_score:.2f}"
        )
        formula_p.runs[0].font.color.rgb = _rgb(60, 60, 60)

        doc.add_paragraph()

        # 风险等级说明
        doc.add_heading('风险等级定义', 2)
        risk_tbl = doc.add_table(rows=6, cols=3)
        risk_tbl.style = 'Table Grid'
        for j, h in enumerate(["分数范围", "等级", "建议"]):
            risk_tbl.rows[0].cells[j].text = h
            risk_tbl.rows[0].cells[j].paragraphs[0].runs[0].bold = True
            risk_tbl.rows[0].cells[j].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        risk_data = [
            ("86 – 100", "✅ SAFE",     "安全，可安装"),
            ("71 – 85",  "🟢 LOW",      "低风险，建议审查后安装"),
            ("51 – 70",  "🟡 MEDIUM",   "中等风险，需要人工审查"),
            ("31 – 50",  "🔴 HIGH",     "高风险，建议不安装"),
            ("0 – 30",   "🚨 CRITICAL", "危险，拒绝安装"),
        ]
        for i, (rng, lvl, rec) in enumerate(risk_data, 1):
            risk_tbl.rows[i].cells[0].text = rng
            risk_tbl.rows[i].cells[1].text = lvl
            risk_tbl.rows[i].cells[2].text = rec
            risk_tbl.rows[i].cells[0].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
            risk_tbl.rows[i].cells[1].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

        doc.add_page_break()

        # ═══════════════════════════════════════════════════════════════════════
        #  第3块: 详细的 Checklist（分层展示）
        # ═══════════════════════════════════════════════════════════════════════
        doc.add_heading('三、详细的 Checklist', 1)

        layer_checklist_sections = [
            {
                "title": "3.1  Layer 1 — 正则表达式静态扫描（Regex Scan）",
                "desc": "通过正则规则检测 Skill 代码中的硬编码凭据、危险函数、网络通信、文件操作等静态特征。",
                "checklist": result.layer1_checklist,
                "score": result.layer1_score,
                "details": result.layer1_details,
            },
            {
                "title": "3.2  Layer 2 — 代码安全与权限评估（Code Security Eval）",
                "desc": "检测代码执行、凭证访问、外部网络请求、子进程调用、环境变量滥用等权限与数据安全风险。",
                "checklist": result.layer2_checklist,
                "score": result.layer2_score,
                "details": result.layer2_details,
            },
            {
                "title": "3.3  Layer 3 — RAG 知识库语义扫描（RAG Scan）",
                "desc": "基于语义相似度，检测 Skill 是否存在访问敏感数据、未授权通信、知识库污染等 RAG 层风险。",
                "checklist": result.layer3_checklist,
                "score": result.layer3_score,
                "details": result.layer3_details,
            },
        ]

        for sidx, sec in enumerate(layer_checklist_sections):
            # 子标题
            sub_h = doc.add_heading(sec["title"], 2)

            # 评分 + 统计行
            sc_p = doc.add_paragraph()
            sc_p.add_run(f"本层评分: ").bold = True
            sc_val = sc_p.add_run(f"{sec['score']:.1f} / 100")
            sc_val.bold = True
            sc_val.font.size = Pt(12)
            if sec['score'] >= 86:
                sc_val.font.color.rgb = _rgb(0, 140, 0)
            elif sec['score'] >= 71:
                sc_val.font.color.rgb = _rgb(0, 180, 0)
            elif sec['score'] >= 51:
                sc_val.font.color.rgb = _rgb(230, 145, 0)
            else:
                sc_val.font.color.rgb = _rgb(200, 0, 0)
            sc_p.add_run("  |")
            _add_stats_bar(sec["checklist"])

            # 描述
            doc.add_paragraph(sec["desc"]).runs[0].font.color.rgb = _rgb(80, 80, 80)

            # Checklist 表格
            _add_checklist_table(sec["checklist"])

            # ── Layer1 专属：全部发现列表 ────────────────────────────────────
            if sidx == 0 and sec["details"] and sec["details"].get("findings"):
                all_findings = sec["details"].get("findings", [])
                scan_stats = sec["details"].get("scan_stats", {})
                if scan_stats:
                    doc.add_heading('扫描统计', 3)
                    st = doc.add_table(rows=3, cols=2)
                    st.style = 'Table Grid'
                    for i2, (k, v) in enumerate([
                        ("扫描文件数", str(scan_stats.get("files_scanned", "?"))),
                        ("扫描代码行数", str(scan_stats.get("lines_scanned", "?"))),
                        ("发现总数", str(scan_stats.get("total_findings", len(all_findings)))),
                    ]):
                        st.rows[i2].cells[0].text = k
                        st.rows[i2].cells[1].text = v
                        st.rows[i2].cells[0].paragraphs[0].runs[0].bold = True
                    doc.add_paragraph()

                if all_findings:
                    doc.add_heading(f'全部发现列表（共 {len(all_findings)} 条）', 3)
                    crit = [f for f in all_findings if f["level"] == "CRITICAL"]
                    high = [f for f in all_findings if f["level"] == "HIGH"]
                    med  = [f for f in all_findings if f["level"] == "MEDIUM"]
                    low  = [f for f in all_findings if f["level"] == "LOW"]
                    sev_groups = [
                        ("🔴 CRITICAL", crit, _rgb(160, 0, 0)),
                        ("🔴 HIGH",     high, _rgb(220, 60, 0)),
                        ("🟡 MEDIUM",   med,  _rgb(200, 150, 0)),
                        ("🟢 LOW",      low,  _rgb(0, 160, 0)),
                    ]
                    for sev_label, group, sev_color in sev_groups:
                        if not group:
                            continue
                        pg = doc.add_paragraph()
                        r_grp = pg.add_run(f"{sev_label}（{len(group)} 条）")
                        r_grp.bold = True
                        r_grp.font.color.rgb = sev_color
                        for f in group:
                            path_s = f.get("path", "SKILL.md")
                            fname = path_s.rsplit("\\", 1)[-1] if "\\" in path_s else path_s
                            fname = fname.rsplit("/", 1)[-1] if "/" in fname else fname
                            raw_desc = f.get("desc", "")
                            for emo in ["🔴", "🟠", "🟡", "⚫"]:
                                raw_desc = raw_desc.replace(emo, "").strip()
                            raw_desc = _re.sub(r'^\s*\d+\.\s*', '', raw_desc).strip()
                            pf = doc.add_paragraph(style='List Number')
                            pf.paragraph_format.left_indent = Inches(0.25)
                            rp = pf.add_run(f"{fname} — {raw_desc}")
                            rp.font.size = Pt(9)
                            rp.font.color.rgb = sev_color
                    doc.add_paragraph()

                    # 假阳性提示
                    priv_rel = [f for f in all_findings
                                if "sudo" in f.get("desc", "").lower()
                                or "iptables" in f.get("desc", "").lower()
                                or f.get("category", "") == "权限提升"]
                    if priv_rel and len(priv_rel) >= len(all_findings) * 0.5:
                        doc.add_heading('⚠ 假阳性说明', 3)
                        p_fp = doc.add_paragraph(
                            f"本轮扫描共检测到 {len(priv_rel)} 条「权限提升」相关发现。"
                            "经核实，这些均为 Skill 正常使用系统调用指令时产生的合法行为（属于 Skill 预期功能，非漏洞）。"
                            "Layer1 Regex Scanner 采用通用规则，在教学类 Skill 中会产生大量假阳性，"
                            "Layer1 评分仅供参考，请结合检查项说明综合判断。"
                        )
                        p_fp.runs[0].font.color.rgb = _rgb(180, 100, 0)
                        p_fp.runs[0].font.size = Pt(9)

            # ── Layer2 专属：扣分详情 ────────────────────────────────────────
            if sidx == 1 and sec["details"] and sec["details"].get("deductions"):
                deductions = sec["details"].get("deductions", [])
                ded_by_type = sec["details"].get("deduction_by_type", {})
                if deductions:
                    doc.add_heading('风险扣分汇总', 3)
                    if ded_by_type:
                        dt_tbl = doc.add_table(rows=len(ded_by_type)+1, cols=3)
                        dt_tbl.style = 'Table Grid'
                        for j2, h2 in enumerate(["风险类别", "扣分", "级别"]):
                            dt_tbl.rows[0].cells[j2].text = h2
                            dt_tbl.rows[0].cells[j2].paragraphs[0].runs[0].bold = True
                            dt_tbl.rows[0].cells[j2].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                        dw_map = {"CRITICAL": -30, "HIGH": -20, "MEDIUM": -10, "LOW": -5}
                        for i2, (key, _) in enumerate(ded_by_type.items(), 1):
                            parts = key.split(":", 1)
                            lvl = parts[0]
                            label = parts[1] if len(parts) > 1 else key
                            dw = abs(dw_map.get(lvl, 0))
                            dt_tbl.rows[i2].cells[0].text = label
                            dt_tbl.rows[i2].cells[1].text = f"-{dw}"
                            dt_tbl.rows[i2].cells[2].text = lvl
                            for c in dt_tbl.rows[i2].cells:
                                c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                        doc.add_paragraph()
                    # 详细发现
                    doc.add_heading('详细发现', 3)
                    for d in deductions[:20]:
                        lvl_color = _rgb(200, 0, 0) if d["level"] == "CRITICAL" \
                                    else _rgb(220, 100, 0) if d["level"] == "HIGH" \
                                    else _rgb(200, 150, 0)
                        pd = doc.add_paragraph(style='List Bullet')
                        pd.paragraph_format.left_indent = Inches(0.25)
                        raw_label = d.get('label', '')
                        raw_detail = d.get('detail', '')
                        clean_label = _re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\r\n]', ' ', raw_label)
                        clean_detail = _re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\r\n]', ' ', raw_detail)
                        r_d = pd.add_run(f"[{d['level']}] {clean_label} — {d.get('file', '')} | {clean_detail}")
                        r_d.font.size = Pt(9)
                        r_d.font.color.rgb = lvl_color
                    doc.add_paragraph()

            # ── Layer3 专属：TOP MATCHES ────────────────────────────────────
            if sidx == 2 and sec["details"] and sec["details"].get("matches"):
                matches = sec["details"].get("matches", [])
                mc = sec["details"].get("matches_count", {})
                kb = sec["details"].get("knowledge_base_entries", 0)
                if matches:
                    doc.add_heading(f'TOP MATCHES（{len(matches)} 条）', 3)
                    mt = doc.add_table(rows=len(matches)+1, cols=4)
                    mt.style = 'Table Grid'
                    for j2, h2 in enumerate(["名称", "类型", "相似度", "严重程度"]):
                        mt.rows[0].cells[j2].text = h2
                        mt.rows[0].cells[j2].paragraphs[0].runs[0].bold = True
                        mt.rows[0].cells[j2].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                    for i2, m in enumerate(matches, 1):
                        mr = mt.rows[i2]
                        mr.cells[0].text = m.get("name", "")
                        mr.cells[1].text = m.get("label", "")
                        sim = m.get("similarity", 0)
                        mr.cells[2].text = f"{sim:.2f}"
                        sev = m.get("severity", "UNKNOWN")
                        sc_cell = mr.cells[3]
                        sc_cell.text = ""
                        r_sev = sc_cell.paragraphs[0].add_run(sev)
                        if sim >= 0.3:    r_sev.font.color.rgb = _rgb(180, 0, 0)
                        elif sim >= 0.2:  r_sev.font.color.rgb = _rgb(220, 100, 0)
                        elif sim >= 0.1:  r_sev.font.color.rgb = _rgb(200, 150, 0)
                        else:             r_sev.font.color.rgb = _rgb(0, 140, 0)
                        prev = m.get("preview", "")
                        if prev:
                            mr.cells[0].paragraphs[0].add_run(f"  — {_clean_text(prev[:80])}").font.size = Pt(8)
                        for c in mr.cells:
                            c.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                    doc.add_paragraph()

            if sidx < len(layer_checklist_sections) - 1:
                doc.add_page_break()

        doc.add_page_break()

        # ═══════════════════════════════════════════════════════════════════════
        #  第4块: 整体综合判定和建议
        # ═══════════════════════════════════════════════════════════════════════
        doc.add_heading('四、整体综合判定和建议', 1)

        # 判定结果框
        verdict_tbl = doc.add_table(rows=3, cols=2)
        verdict_tbl.style = 'Table Grid'
        verdict_tbl.alignment = WD_TABLE_ALIGNMENT.LEFT
        verdict_data = [
            ("综合评分", f"{result.total_score:.1f} / 100"),
            ("风险等级", result.risk_level.value),
            ("建议", result.recommendation),
        ]
        for i, (k, v) in enumerate(verdict_data):
            verdict_tbl.rows[i].cells[0].text = k
            verdict_tbl.rows[i].cells[0].paragraphs[0].runs[0].bold = True
            verdict_tbl.rows[i].cells[1].text = v
        # 综合评分格颜色
        score_cell = verdict_tbl.rows[0].cells[1]
        score_cell.paragraphs[0].runs[0].font.color.rgb = RISK_COLOR.get(result.risk_level, _rgb(0, 0, 0))
        score_cell.paragraphs[0].runs[0].bold = True
        verdict_tbl.rows[0].cells[1].paragraphs[0].runs[0].font.size = Pt(14)
        doc.add_paragraph()

        # 分级建议
        rec_texts = {
            RiskLevel.SAFE: (
                "该 Skill 已通过全部三层安全检查，未发现明显安全风险。\n"
                "✓ 所有检查项均通过，可安全安装使用。"
            ),
            RiskLevel.LOW: (
                "该 Skill 存在低风险项，建议在审查以下内容后安装：\n"
                "• 检查 Checklist 中标记为 WARN 的项目\n"
                "• 确认 Skill 来源可信\n"
                "• 在低权限环境中先行测试运行"
            ),
            RiskLevel.MEDIUM: (
                "⚠ 该 Skill 存在中等风险，安装前需要人工审查：\n"
                "• 必须逐条核实 FAIL / WARN 检查项\n"
                "• 确认 Skill 作者身份和代码仓库完整性\n"
                "• 在隔离环境中测试，监控网络和行为\n"
                "• 建议团队安全负责人审批后再安装"
            ),
            RiskLevel.HIGH: (
                "⚠ 该 Skill 存在高风险，强烈建议不要安装：\n"
                "• 存在明确的 FAIL 检查项，可能造成安全风险\n"
                "• 如必须安装，需完整代码审计 + 沙箱隔离运行\n"
                "• 建议寻找具有相同功能但更安全的替代 Skill"
            ),
            RiskLevel.CRITICAL: (
                "🚨 该 Skill 存在严重安全风险，禁止安装：\n"
                "• 检测到明确的恶意行为特征\n"
                "• 应立即上报安全团队\n"
                "• 如已安装，立即卸载并审查影响范围"
            ),
        }
        rec_p = doc.add_paragraph(rec_texts.get(result.risk_level, ""))
        if result.risk_level == RiskLevel.HIGH or result.risk_level == RiskLevel.CRITICAL:
            for run in rec_p.runs:
                run.font.color.rgb = _rgb(200, 0, 0)
        elif result.risk_level == RiskLevel.MEDIUM:
            for run in rec_p.runs:
                run.font.color.rgb = _rgb(200, 100, 0)

        # 执行错误
        if result.errors:
            doc.add_heading('执行警告', 2)
            for e in result.errors:
                pe = doc.add_paragraph(f"• {e}")
                pe.runs[0].font.color.rgb = _rgb(200, 80, 0)

        doc.add_page_break()

        # ═══════════════════════════════════════════════════════════════════════
        #  第5块: 关键发现及安全分析
        # ═══════════════════════════════════════════════════════════════════════
        doc.add_heading('五、关键发现及安全分析', 1)

        all_critical_failures = []
        all_warnings = []
        all_layer_highlights = []

        # 收集各层 FAIL/WARN
        for lname, lchecklist, ldetails in [
            ("Layer 1", result.layer1_checklist, result.layer1_details),
            ("Layer 2", result.layer2_checklist, result.layer2_details),
            ("Layer 3", result.layer3_checklist, result.layer3_details),
        ]:
            for ci in lchecklist:
                if ci.status == "FAIL":
                    all_critical_failures.append((lname, ci))
                elif ci.status == "WARN":
                    all_warnings.append((lname, ci))

            # Layer1 高危发现摘要
            if lname == "Layer 1" and ldetails and ldetails.get("findings"):
                hf = ldetails["findings"]
                crit_f = [f for f in hf if f["level"] == "CRITICAL"][:3]
                high_f = [f for f in hf if f["level"] == "HIGH"][:5]
                if crit_f or high_f:
                    all_layer_highlights.append(("Layer 1", crit_f + high_f))

            # Layer2 扣分摘要
            if lname == "Layer 2" and ldetails and ldetails.get("deductions"):
                deds = ldetails["deductions"][:5]
                if deds:
                    all_layer_highlights.append(("Layer 2", deds))

            # Layer3 高相似度匹配
            if lname == "Layer 3" and ldetails and ldetails.get("matches"):
                hm = [m for m in ldetails["matches"] if m.get("similarity", 0) >= 0.2][:5]
                if hm:
                    all_layer_highlights.append(("Layer 3", hm))

        # 关键失败项
        if all_critical_failures:
            doc.add_heading('关键失败项（FAIL）', 2)
            for lname, ci in all_critical_failures:
                pb = doc.add_paragraph(style='List Bullet')
                pb.paragraph_format.left_indent = Inches(0.25)
                r_lbl = pb.add_run(f"[{lname}] ")
                r_lbl.bold = True
                r_lbl.font.color.rgb = _rgb(200, 0, 0)
                r_lbl.font.size = Pt(10)
                r_item = pb.add_run(f"{_clean_text(ci.id)} {_clean_text(ci.item)}")
                r_item.bold = True
                r_item.font.color.rgb = _rgb(200, 0, 0)
                if ci.detail:
                    pb2 = doc.add_paragraph(style='List Bullet')
                    pb2.paragraph_format.left_indent = Inches(0.6)
                    r2 = pb2.add_run(f"说明: {_clean_text(ci.detail)} {_clean_text(ci.evidence)}")
                    r2.font.size = Pt(9)
                    r2.font.color.rgb = _rgb(120, 0, 0)
        else:
            p = doc.add_paragraph("✅ 各层均未发现关键失败项。")
            p.runs[0].font.color.rgb = _rgb(0, 140, 0)
            p.runs[0].bold = True

        doc.add_paragraph()

        # 警告项
        if all_warnings:
            doc.add_heading('警告项（WARN）', 2)
            for lname, ci in all_warnings:
                pb = doc.add_paragraph(style='List Bullet')
                pb.paragraph_format.left_indent = Inches(0.25)
                r_lbl = pb.add_run(f"[{lname}] ")
                r_lbl.bold = True
                r_lbl.font.color.rgb = _rgb(230, 145, 0)
                r_lbl.font.size = Pt(10)
                r_item = pb.add_run(f"{_clean_text(ci.id)} {_clean_text(ci.item)}")
                r_item.bold = True
                r_item.font.color.rgb = _rgb(230, 145, 0)
                if ci.detail:
                    pb2 = doc.add_paragraph(style='List Bullet')
                    pb2.paragraph_format.left_indent = Inches(0.6)
                    r2 = pb2.add_run(f"说明: {_clean_text(ci.detail)}")
                    r2.font.size = Pt(9)
                    r2.font.color.rgb = _rgb(180, 120, 0)

        doc.add_paragraph()

        # 各层高危发现摘要
        if all_layer_highlights:
            doc.add_heading('各层高危发现摘要', 2)
            for lname, items in all_layer_highlights:
                doc.add_heading(f'■ {lname}', 3)
                if lname == "Layer 1":
                    for f in items:
                        lvl_c = _rgb(160, 0, 0) if f["level"] == "CRITICAL" else _rgb(220, 60, 0)
                        pf = doc.add_paragraph(style='List Bullet')
                        pf.paragraph_format.left_indent = Inches(0.25)
                        r_pf = pf.add_run(f"[{f['level']}] {_clean_text(f.get('path', ''))} — {_clean_text(f.get('desc', ''))}")
                        r_pf.font.size = Pt(9)
                        r_pf.font.color.rgb = lvl_c
                elif lname == "Layer 2":
                    for d in items:
                        lvl_c = _rgb(200, 0, 0) if d["level"] == "CRITICAL" else \
                                _rgb(220, 100, 0) if d["level"] == "HIGH" else \
                                _rgb(200, 150, 0)
                        pf = doc.add_paragraph(style='List Bullet')
                        pf.paragraph_format.left_indent = Inches(0.25)
                        r_pf = pf.add_run(f"[{d['level']}] {_clean_text(d.get('label', ''))} @ {_clean_text(d.get('file', ''))} | {_clean_text(d.get('detail', ''))}")
                        r_pf.font.size = Pt(9)
                        r_pf.font.color.rgb = lvl_c
                elif lname == "Layer 3":
                    for m in items:
                        sim = m.get("similarity", 0)
                        sim_c = _rgb(180, 0, 0) if sim >= 0.3 else _rgb(220, 100, 0)
                        pf = doc.add_paragraph(style='List Bullet')
                        pf.paragraph_format.left_indent = Inches(0.25)
                        r_pf = pf.add_run(
                            f"{_clean_text(m.get('name', ''))} ({_clean_text(m.get('label', ''))}, 相似度: {sim:.2f})"
                            + (f" | {_clean_text(m.get('preview', '')[:60])}" if m.get('preview') else "")
                        )
                        r_pf.font.size = Pt(9)
                        r_pf.font.color.rgb = sim_c

        doc.add_page_break()

        # ═══════════════════════════════════════════════════════════════════════
        #  第6块: 附录：原始输出
        # ═══════════════════════════════════════════════════════════════════════
        doc.add_heading('六、附录：原始输出', 1)

        def _add_raw_section(title: str, raw: str, max_chars: int = 6000):
            doc.add_heading(title, 2)
            if not raw:
                p = doc.add_paragraph("（无原始数据）")
                p.runs[0].font.color.rgb = _rgb(140, 140, 140)
                p.runs[0].italic = True
                return
            display = raw[:max_chars]
            truncated = len(raw) > max_chars
            p_raw = doc.add_paragraph(display)
            for run in p_raw.runs:
                run.font.name = 'Consolas'
                run.font.size = Pt(8)
                run.font.color.rgb = _rgb(50, 50, 50)
            if truncated:
                p_note = doc.add_paragraph(f"（以上为截断显示，共 {len(raw)} 字符）")
                p_note.runs[0].font.color.rgb = _rgb(140, 140, 140)
                p_note.runs[0].italic = True
            doc.add_paragraph()

        _add_raw_section('A.1  Layer 1 — Regex Scanner 原始输出', result.layer1_raw)
        _add_raw_section('A.2  Layer 2 — Code Security Eval 原始输出', result.layer2_raw)
        _add_raw_section('A.3  Layer 3 — RAG Scanner 原始输出', result.layer3_raw)

        # 附录B: 完整 JSON 结构
        doc.add_heading('A.4  结构化 JSON 评分数据', 2)
        json_data = {
            "skill": result.skill_name,
            "path": result.skill_path,
            "scan_time": result.scan_time,
            "execution_time": f"{result.execution_time:.2f}s",
            "total_score": result.total_score,
            "risk_level": result.risk_level.value,
            "recommendation": result.recommendation,
            "scores": {
                "layer1": {"score": result.layer1_score, "weight": 0.35},
                "layer2": {"score": result.layer2_score, "weight": 0.35},
                "layer3": {"score": result.layer3_score, "weight": 0.30},
            },
        }
        json_str = json.dumps(json_data, indent=2, ensure_ascii=False)
        pj = doc.add_paragraph(json_str)
        for run in pj.runs:
            run.font.name = 'Consolas'
            run.font.size = Pt(8)
            run.font.color.rgb = _rgb(50, 50, 50)

        # ── 保存 ────────────────────────────────────────────────────────────
        out = Path(output_path)
        if not out.suffix:
            out = out.with_suffix(".docx")
        out.parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(out))
        return str(out)

    def _extract_skill_intro(self, skill_path: str) -> List[str]:
        """从 SKILL.md 中提取 Skill 简介（用途、适用场景）"""
        skill_p = Path(skill_path)
        # 尝试找到 SKILL.md
        candidates = [
            skill_p / "SKILL.md",
            skill_p.with_name("SKILL.md"),
        ]
        for cp in candidates:
            if cp.exists():
                try:
                    content = cp.read_text(encoding='utf-8', errors='ignore')
                    lines = content.splitlines()
                    result_lines: List[str] = []
                    in_section = False
                    # 提取各 markdown 章节（## 开头的）
                    collecting = False
                    collected: List[str] = []
                    for line in lines:
                        stripped = line.strip()
                        if stripped.startswith('## '):
                            if collecting and collected:
                                result_lines.extend(collected[:30])  # 限制每节行数
                                collected = []
                            if any(kw in stripped for kw in ['用途', '场景', '介绍', '简介', '功能', '说明']):
                                collecting = True
                                result_lines.append(stripped)
                        elif collecting:
                            if stripped.startswith('#') or len(collected) > 30:
                                break
                            if stripped:
                                collected.append(stripped)
                    if collecting and collected:
                        result_lines.extend(collected[:10])
                    # 降级：取前40行非空内容
                    if not result_lines:
                        for line in lines[:60]:
                            s = line.strip()
                            if s and not s.startswith('#'):
                                result_lines.append(s)
                            elif s.startswith('#') and len(result_lines) < 5:
                                result_lines.append(s)
                        result_lines = result_lines[:40]
                    return result_lines
                except Exception:
                    pass
        return []


# ══════════════════════════════════════════════════════════════════════════════
# 入口函数（Python API）
# ══════════════════════════════════════════════════════════════════════════════

def aggregate_score(skill_path: str, verbose: bool = False) -> AggregatedResult:
    """聚合指定 Skill 的安全评分"""
    aggregator = SecurityAggregator()
    return aggregator.aggregate(Path(skill_path), verbose=verbose)


def main():
    """命令行入口"""
    import argparse
    parser = argparse.ArgumentParser(description="Skill Security Aggregator — 生成 DOCX/JSON/Text 报告")
    parser.add_argument("path", help="Skill 目录路径")
    parser.add_argument("--verbose", "-v", action="store_true", help="详细输出")
    parser.add_argument("--json",  "-j", action="store_true", help="输出 JSON 到 stdout")
    parser.add_argument("--docx",  "-d", help="生成 DOCX 报告（指定输出路径）")
    parser.add_argument("--output", "-o", help="[废弃] 输出文件路径（根据扩展名自动判断格式）")

    args = parser.parse_args()

    result = aggregate_score(args.path, verbose=args.verbose)
    agg = SecurityAggregator()

    # 判断输出模式
    docx_path = args.docx or (args.output if args.output and args.output.endswith(".docx") else None)
    json_mode = args.json or (args.output and args.output.endswith(".json"))
    text_mode = not docx_path and not json_mode

    if docx_path:
        if not _HAS_DOCX:
            print("[ERROR] python-docx 未安装，请运行: pip install python-docx", file=sys.stderr)
            sys.exit(3)
        out_file = agg.get_docx_report(result, docx_path)
        print(f"DOCX 报告已生成: {out_file}")
    elif json_mode:
        out_file = args.output if args.output else None
        content = agg.get_json_report(result)
        if out_file:
            Path(out_file).write_text(content, encoding='utf-8')
            print(f"JSON 报告已保存: {out_file}")
        else:
            print(content)
    else:
        print(agg.get_report(result))

    # 返回码
    if result.risk_level in [RiskLevel.CRITICAL, RiskLevel.HIGH]:
        sys.exit(2)
    elif result.risk_level == RiskLevel.MEDIUM:
        sys.exit(1)
    else:
        sys.exit(0)


if __name__ == "__main__":
    main()
