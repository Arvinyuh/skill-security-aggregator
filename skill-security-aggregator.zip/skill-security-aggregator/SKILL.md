# Skill Security Aggregator

综合安全评分聚合器。调用 Layer1、Layer2、Layer3 三个独立 Skill，计算最终安全评分，**生成含三层 Checklist 的 DOCX/JSON/Text 详细报告**。

## 架构

```
┌─────────────────────────────────────────────────────────────────────────┐
│                     Security Aggregator                                │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                       │
│  ┌─────────────┐   ┌─────────────┐   ┌─────────────┐                │
│  │ Layer1      │   │ Layer2      │   │ Layer3      │                │
│  │ Regex Scan  │   │ Prompt Eval │   │ RAG Scan    │                │
│  │ (100分,35%) │   │ (100分,35%) │   │ (100分,30%) │                │
│  └──────┬──────┘   └──────┬──────┘   └──────┬──────┘                │
│         │                  │                  │                       │
│         └──────────────────┴──────────────────┘                       │
│                            │                                          │
│                            ▼                                          │
│                ┌───────────────────────┐                              │
│                │     Aggregator        │                              │
│                │  计算综合评分 +        │                              │
│                │  生成三层 Checklist   │                              │
│                │  DOCX/JSON/Text 报告 │                              │
│                └───────────────────────┘                              │
│                                                                       │
└─────────────────────────────────────────────────────────────────────────┘
```

## 评分体系

| Layer | Skill | 分值范围 | 权重 | Checklist 项数 |
|-------|-------|----------|------|-----------------|
| Layer1 | skill-layer1-regex-scan | 0-100 | 35% | 8 项 |
| Layer2 | skill-layer2-prompt-eval | 0-100 | 35% | 7 项 |
| Layer3 | skill-layer3-rag | 0-100 | 30% | 6 项 |

> **Checklist 说明**：每个 Layer 有独立的默认 Checklist（见下文），若各层脚本返回结构化 JSON（含 `checklist` 字段），则使用实际检查结果。

## 综合评分计算

```
综合分数 = Layer1 × 0.35 + Layer2 × 0.35 + Layer3 × 0.30
```

## 风险等级

| 分数范围 | 风险等级 | 建议 |
|----------|----------|------|
| 86-100 | ✅ SAFE | 安全，可安装 |
| 71-85  | 🟢 LOW | 低风险，建议审查后安装 |
| 51-70  | 🟡 MEDIUM | 中等风险，需要人工审查 |
| 31-50  | 🔴 HIGH | 高风险，建议不安装 |
| 0-30   | 🚨 CRITICAL | 危险，拒绝安装 |

## 三层 Checklist 定义

### Layer1 — Regex Scan Checklist（8 项）

| 编号 | 检查项 | 类别 |
|-------|--------|------|
| L1-01 | 硬编码凭据检测（密码/Token/API Key） | 凭据泄露 |
| L1-02 | 危险函数调用检测（eval/exec/os.system） | 代码执行 |
| L1-03 | 网络通信检测（socket/requests/urllib） | 数据外泄 |
| L1-04 | 文件系统访问检测（open/write/file） | 文件操作 |
| L1-05 | 混淆代码检测（encode/encrypt/压缩） | 混淆规避 |
| L1-06 | 环境变量滥用检测 | 权限提升 |
| L1-07 | 子进程调用检测（subprocess/popen） | 代码执行 |
| L1-08 | 动态导入检测（\_\_import\_\_/importlib） | 动态加载 |

### Layer2 — Prompt Eval Checklist（7 项）

| 编号 | 检查项 | 类别 |
|-------|--------|------|
| L2-01 | Prompt 注入模式检测（指令覆盖） | Prompt注入 |
| L2-02 | 系统提示词泄露风险 | 信息泄露 |
| L2-03 | 越狱（Jailbreak）模式检测 | Prompt注入 |
| L2-04 | 上下文操纵检测 | Prompt注入 |
| L2-05 | 角色扮演绕过检测 | Prompt注入 |
| L2-06 | 分隔符注入检测 | Prompt注入 |
| L2-07 | 输出过滤绕过检测 | 输出管控 |

### Layer3 — RAG Scan Checklist（6 项）

| 编号 | 检查项 | 类别 |
|-------|--------|------|
| L3-01 | 敏感数据访问检测（密码/Token/私钥） | 数据泄露 |
| L3-02 | 外部 API 调用检测（未授权通信） | 数据外泄 |
| L3-03 | RAG 知识库污染检测 | 数据投毒 |
| L3-04 | 文件路径遍历检测 | 文件操作 |
| L3-05 | 个人信息泄露检测（PII） | 隐私违规 |
| L3-06 | 跨 Skill 数据泄漏检测 | 横向移动 |

> Checklist 状态：`PASS`（通过）/ `FAIL`（失败）/ `WARN`（警告）/ `MANUAL`（待人工）

---

## 使用方法

### 命令行

```bash
# 文本报告（默认）
python scripts/aggregator.py /path/to/skill
python scripts/aggregator.py /path/to/skill --verbose

# JSON 报告
python scripts/aggregator.py /path/to/skill --json
python scripts/aggregator.py /path/to/skill --json --output report.json

# DOCX 详细报告（含三层 Checklist）
python scripts/aggregator.py /path/to/skill --docx report.docx
python scripts/aggregator.py /path/to/skill -d report.docx --verbose
```

### Python API

```python
from scripts.aggregator import aggregate_score, SecurityAggregator, AggregatedResult

# 聚合评分
result: AggregatedResult = aggregate_score("/path/to/skill", verbose=True)

# 访问评分
print(f"综合分数:   {result.total_score:.0f}/100")
print(f"风险等级:   {result.risk_level.value}")
print(f"Layer1 分数: {result.layer1_score:.0f}/100")
print(f"Layer2 分数: {result.layer2_score:.0f}/100")
print(f"Layer3 分数: {result.layer3_score:.0f}/100")

# 访问三层 Checklist
for ci in result.layer1_checklist:
    print(f"  [{ci.status}] {ci.id} {ci.item}")

# 生成 DOCX 报告
agg = SecurityAggregator()
docx_path = agg.get_docx_report(result, "security_report.docx")
print(f"DOCX 报告: {docx_path}")

# 生成 JSON 报告（含 checklist）
json_str = agg.get_json_report(result)
```

---

## DOCX 报告结构（六段式）

生成的 DOCX 报告采用六段式结构：

```
封面     — SKILL SECURITY ASSESSMENT REPORT [skill_name]
           综合评分（大字号）、风险等级、建议、Skill 元信息

第1块    — 一、Skill 简介
           从 SKILL.md 自动提取用途、适用场景、主要功能说明

第2块    — 二、总体安全评价总览
           各层分数 + 权重 + 加权贡献表
           计算公式：Layer1×0.35 + Layer2×0.35 + Layer3×0.30
           风险等级定义表（SAFE/LOW/MEDIUM/HIGH/CRITICAL）

第3块    — 三、详细的 Checklist（分层展示）
           3.1 Layer 1 — 正则表达式静态扫描
               本层评分 + 统计条 + Checklist 表格 + 全部发现列表 + 假阳性说明
           3.2 Layer 2 — 代码安全与权限评估
               本层评分 + 统计条 + Checklist 表格 + 扣分汇总 + 详细发现
           3.3 Layer 3 — RAG 知识库语义扫描
               本层评分 + 统计条 + Checklist 表格 + TOP MATCHES 列表

第4块    — 四、整体综合判定和建议
           判定结果框（评分/等级/建议）
           按风险等级给出分级处置建议
           执行警告列表（若有）

第5块    — 五、关键发现及安全分析
           关键失败项（FAIL）汇总
           警告项（WARN）汇总
           各层高危发现摘要（按严重程度颜色标注）

第6块    — 六、附录：原始输出
           A.1 Layer 1 原始输出
           A.2 Layer 2 原始输出
           A.3 Layer 3 原始输出
           A.4 结构化 JSON 评分数据
```

---

## 输出示例

### 文本报告（终端）

```
══════════════════════════════════════════════════════════════
         SKILL SECURITY AGGREGATED REPORT
══════════════════════════════════════════════════════════════
Skill:       example-skill
Path:        /path/to/example-skill
Scanned:     2025-01-01T00:00:00
Execution:   3.21s
────────────────────────────────────────────────────────────────

LAYER SCORES:
┌─────────────┬──────────┬────────┬──────────┐
│ Layer       │ Score    │ Weight │ Contrib  │
├─────────────┼──────────┼────────┼──────────┤
│ Layer1      │   85.0/100 │ 35%   │   29.8    │
│ Layer2      │   72.0/100 │ 35%   │   25.2    │
│ Layer3      │   90.0/100 │ 30%   │   27.0    │
└─────────────┴──────────┴────────┴──────────┘

WEIGHTED CALCULATION:
  85.0×0.35 + 72.0×0.35 + 90.0×0.30 = 81.95

CHECKLIST: Layer1 - Regex Scan
  ✓ PASS: 6   ✗ FAIL: 1   ⚠ WARN: 1   ? MANUAL: 0

CHECKLIST: Layer2 - Prompt Eval
  ✓ PASS: 5   ✗ FAIL: 1   ⚠ WARN: 1   ? MANUAL: 0

CHECKLIST: Layer3 - RAG Scan
  ✓ PASS: 6   ✗ FAIL: 0   ⚠ WARN: 0   ? MANUAL: 0

────────────────────────────────────────────────────────────────

══════════════════════════════════════════════════════════════
FINAL SCORE: 82/100
RISK LEVEL:  🟢 LOW
RECOMMEND:  低风险，建议审查后安装
══════════════════════════════════════════════════════════════
```

### JSON 报告（摘录）

```json
{
  "skill": {"name": "example-skill", "path": "/path/to/example-skill"},
  "total_score": 81.95,
  "risk_level": "LOW",
  "recommendation": "低风险，建议审查后安装",
  "checklists": {
    "layer1": [
      {"id": "L1-01", "item": "硬编码凭据检测", "category": "凭据泄露", "status": "PASS", "detail": ""},
      {"id": "L1-03", "item": "网络通信检测",   "category": "数据外泄", "status": "FAIL", "detail": "发现 requests.post 调用"}
    ],
    "layer2": [...],
    "layer3": [...]
  }
}
```

---

## 单独运行各层

```bash
# 仅运行 Layer1
python ../skill-layer1-regex-scan/scripts/regex_scanner.py /path/to/skill

# 仅运行 Layer2
python ../skill-layer2-prompt-eval/scripts/prompt_evaluator.py /path/to/skill

# 仅运行 Layer3
python ../skill-layer3-rag/scripts/rag_scanner.py /path/to/skill
```

> **提示**：若各层脚本在 JSON 输出中包含 `checklist` 字段，aggregator 会直接采用，不再使用默认 checklist。

---

## 依赖

- Python 3.8+
- **python-docx**（生成 DOCX 报告需要）— `pip install python-docx`
- 各层 Skill 脚本存在即可运行（缺失时给 50 分 + MANUAL 状态）

---

## 适用场景

- 完整的 Skill 安全评估（含 Checklist 审计报告）
- CI/CD 集成（JSON 输出可机读）
- 批量扫描 + 导出 DOCX 报告归档
- 安全合规审计报告（含签名页）
- 团队内部 Skill 审批流程
