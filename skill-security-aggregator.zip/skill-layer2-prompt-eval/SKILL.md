# Layer2: Prompt-Based Security Evaluation

基于 AI Prompt 的安全评估协议。不使用任何 Python 脚本，仅依靠本 SKILL.md 文件本身生成 prompt 针对目标 Skill 进行评估。

---

## 审查协议

### 步骤 1：来源检查

Questions to answer:
- [ ] Where did this skill come from?
- [ ] Is the author known/reputable?
- [ ] How many downloads/stars does it have?
- [ ] When was it last updated?
- [ ] Are there reviews from other agents?

### 步骤 2：代码审查（强制）

阅读该技能中的所有文件。检查以下危险信号：

🚨 **REJECT IMMEDIATELY IF YOU SEE:**
- curl/wget to unknown URLs
- Sends data to external servers
- Requests credentials/tokens/API keys
- Reads ~/.ssh, ~/.aws, ~/.config without clear reason
- **Accesses MEMORY.md, USER.md, SOUL.md, IDENTITY.md** ← 核心记忆文件
- Uses base64 decode on anything
- Uses eval() or exec() with external input
- Modifies system files outside workspace
- Installs packages without listing them
- Network calls to IPs instead of domains
- Obfuscated code (compressed, encoded, minified)
- Requests elevated/sudo permissions
- Accesses browser cookies/sessions
- Touches credential files

### 步骤 3：权限范围评估

Evaluate:
- [ ] What files does it need to read?
- [ ] What files does it need to write?
- [ ] What commands does it run?
- [ ] Does it need network access? To where?
- [ ] Is the scope minimal for its stated purpose?

### 步骤 4：风险分级与扣分

| 风险等级 | 扣分 | 典型场景 |
|----------|------|----------|
| CRITICAL | **-30 分** | eval/exec、base64 解码、shell=True |
| HIGH | **-20 分** | 子进程、敏感目录访问、环境变量读取 |
| MEDIUM | **-10 分** | 外部 API 调用、文件路径操作 |
| LOW | **-5 分** | 日志输出、代码注释 |

---

## 评分计算方法

```
最终得分 = 100 - Σ(所有发现项扣分)
```

**最低得分：0 分**

### 风险等级判定

| 分数范围 | 风险等级 | 建议 |
|----------|----------|------|
| 86-100 | ✅ SAFE | 安全，可安装 |
| 71-85 | 🟢 LOW | 低风险，建议审查 |
| 51-70 | 🟡 MEDIUM | 中等风险，需要审查 |
| 31-50 | 🔴 HIGH | 高风险，建议不安装 |
| 0-30 | 🚨 CRITICAL | 危险，拒绝安装 |

---

## 快速评估 Prompt

当需要评估目标 Skill 时，使用以下 prompt：

```
## 任务：评估 Skill 安全风险

请审查以下 Skill 文件内容，进行安全评估：

### SKILL.md 内容：
{粘贴 SKILL.md 内容}

### 所有代码文件：
{粘贴所有代码文件内容}

### 评估步骤：

1. **来源检查**：该 Skill 来自哪里？作者是否可信？

2. **危险信号扫描**：
   - 🚨 REJECT：eval/exec、base64、curl/wget、发送外部数据、访问 ~/.ssh/.aws、访问 MEMORY.md/USER.md/SOUL.md
   - ⚠️ HIGH：子进程、os.environ、环境变量读取、subprocess.Popen
   - 🔶 MEDIUM：外部 API (OpenAI/Gemini)、文件路径操作、敏感关键词
   - ℹ️ LOW：日志输出、代码注释

3. **权限范围**：
   - 需要读取哪些文件？
   - 需要写入哪些文件？
   - 需要网络访问吗？
   - 权限是否最小化？

4. **评分计算**：
   ```
   扣分项：
   - CRITICAL: -30分/项
   - HIGH: -20分/项
   - MEDIUM: -10分/项
   - LOW: -5分/项

   最终得分 = 100 - 总扣分
   ```

5. **最终报告**：
   - 发现列表（按严重程度排序）
   - 总扣分
   - 最终得分
   - 风险等级
   - 安装建议
```

---

## 使用示例

### 评估 memory-enhancer Skill

**来源**：ClawHub / Agent Marketplace

**代码审查发现**：
| 检查项 | 结果 | 等级 |
|--------|------|------|
| curl/wget | ❌ 无 | - |
| 发送数据到外部 | ⚠️ 调用 Gemini API | MEDIUM (-10) |
| 访问 MEMORY.md | ⚠️ 写入记忆文件 | HIGH (-20) |
| 子进程执行 | ⚠️ sessions_spawn | HIGH (-20) |
| eval/exec | ❌ 无 | - |
| 日志输出 | ℹ️ console.log | LOW (-5) |

**评分计算**：
```
基础分: 100
- 外部 API 调用 (MEDIUM): -10
- 访问 MEMORY.md (HIGH): -20
- 子进程执行 (HIGH): -20
- 日志输出 (LOW): -5

总扣分: -55
最终得分: 45/100
风险等级: 🔴 HIGH
建议: 高风险，建议不安装
```

---

## 适用场景

- 当需要 AI 辅助理解 Skill 行为时
- 当 Python 环境不可用时
- 当需要详细人工审查报告时
- 作为 Layer1/3 的补充验证层
