# Skill Layer1 - Regex Security Scanner

基于正则表达式和关键字匹配的静态安全扫描工具。

## 功能特点

- **快速扫描**：使用正则规则检测恶意模式
- **多维度检测**：覆盖数据外泄、命令注入、凭证窃取等风险
- **满分100分**：无风险发现得满分，有风险根据严重度扣分
- **详细报告**：输出每个发现的位置和详情

## 检测风险类型

| 类别 | 描述 | 严重度 |
|------|------|--------|
| data_exfiltration | 数据外泄到外部服务器 | CRITICAL |
| command_injection | 命令注入攻击 | CRITICAL |
| credential_theft | 凭证窃取 | CRITICAL |
| filesystem_abuse | 文件系统滥用/破坏 | CRITICAL |
| obfuscation | 代码混淆 | HIGH |
| network_attack | 网络攻击 | MEDIUM-HIGH |
| persistence | 持久化机制 | HIGH |
| prompt_injection | Prompt 注入 | CRITICAL |
| privilege_escalation | 权限提升 | HIGH |

## 扣分规则（满分100）

| 风险等级 | 每次扣分 |
|----------|----------|
| CRITICAL | -25 分 |
| HIGH | -15 分 |
| MEDIUM | -8 分 |
| LOW | -3 分 |

## 使用方法

### 命令行

```bash
python scripts/regex_scanner.py /path/to/skill
python scripts/regex_scanner.py /path/to/skill --aggressive
```

### Python API

```python
from scripts.regex_scanner import scan_skill, ScanResult

# 扫描 Skill
result: ScanResult = scan_skill("/path/to/skill")

# 访问结果
print(f"分数: {result.score}/100")
print(f"发现数: {len(result.findings)}")
for finding in result.findings:
    print(f"  [{finding.severity.name}] {finding.description}")
```

## 输出示例

```
SKILL REGEX SECURITY SCAN
═══════════════════════════════════════════════════════════════
Skill: example-skill
Files Scanned: 15
Lines Scanned: 1,234
Total Findings: 3
───────────────────────────────────────────────────────────────
Risk Distribution:
  CRITICAL: 1
  HIGH: 2
───────────────────────────────────────────────────────────────
SECURITY SCORE: 60/100
═══════════════════════════════════════════════════════════════
```

## 适用场景

- Skill 安装前的安全审查
- 批量扫描多个 Skill
- CI/CD 集成
- 安全合规检测
