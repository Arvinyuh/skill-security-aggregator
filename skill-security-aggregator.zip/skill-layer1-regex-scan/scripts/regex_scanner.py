"""
Skill Layer1: Regex Security Scanner
基于正则规则匹配的安全模式检测
满分100分
"""

import re
import os
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
from enum import Enum
import json


class RiskLevel(Enum):
    """风险等级"""
    SAFE = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


# ═══════════════════════════════════════════════════════════════════════════════
# 恶意模式正则规则库
# ═══════════════════════════════════════════════════════════════════════════════

MALICIOUS_PATTERNS = [
    # 数据外泄
    {
        "id": "DATA_EXFIL_001",
        "pattern": r'(curl|wget|requests\.post|fetch|httpx)\s*\(.*(?:user|pass|token|secret|key|credential|api)',
        "severity": RiskLevel.CRITICAL,
        "description": "可能将凭证外泄到外部服务器",
        "category": "data_exfiltration"
    },
    {
        "id": "DATA_EXFIL_002",
        "pattern": r'(os\.environ|getenv|process\.env)\s*\[.*(?:API|TOKEN|SECRET|KEY|PRIVATE)',
        "severity": RiskLevel.CRITICAL,
        "description": "读取敏感环境变量",
        "category": "data_exfiltration"
    },
    {
        "id": "DATA_EXFIL_003",
        "pattern": r'webhook.*(?:exfiltrate|steal|leak|send.*data)',
        "severity": RiskLevel.CRITICAL,
        "description": "Webhook 用于数据外泄",
        "category": "data_exfiltration"
    },

    # 命令注入
    {
        "id": "CMD_INJ_001",
        "pattern": r'(os\.system|subprocess\.call|subprocess\.run)\s*\([^)]*\)(?!.*shell\s*=\s*False)',
        "severity": RiskLevel.CRITICAL,
        "description": "可能执行任意命令",
        "category": "command_injection"
    },
    {
        "id": "CMD_INJ_002",
        "pattern": r'(exec|eval|compile)\s*[\(\s].*[\)\"]',
        "severity": RiskLevel.CRITICAL,
        "description": "动态代码执行（Python eval/exec 或 Bash eval）",
        "category": "command_injection"
    },
    {
        "id": "CMD_INJ_002_BASH",
        "pattern": r'\beval\s+["\']',
        "severity": RiskLevel.HIGH,
        "description": "Bash eval 动态执行字符串（潜在命令注入）",
        "category": "command_injection"
    },
    {
        "id": "CMD_INJ_003",
        "pattern": r'shell\s*=\s*True',
        "severity": RiskLevel.HIGH,
        "description": "subprocess 使用 shell=True",
        "category": "command_injection"
    },
    {
        "id": "CMD_INJ_004",
        "pattern": r'os\.popen\(',
        "severity": RiskLevel.HIGH,
        "description": "os.popen 可能导致命令注入",
        "category": "command_injection"
    },

    # 凭证窃取
    {
        "id": "CRED_THEFT_001",
        "pattern": r'\.(ssh|aws|gcp|azure|api_key|bearer|credentials)\s*\)',
        "severity": RiskLevel.CRITICAL,
        "description": "尝试访问凭证文件",
        "category": "credential_theft"
    },
    {
        "id": "CRED_THEFT_002",
        "pattern": r'(keyring|crypto|jose|jwt\.decode|pbkdf2)',
        "severity": RiskLevel.HIGH,
        "description": "涉及加密/密钥操作",
        "category": "credential_theft"
    },
    {
        "id": "CRED_THEFT_003",
        "pattern": r'(getpass|getuser|keychain|keyring)',
        "severity": RiskLevel.HIGH,
        "description": "尝试获取系统凭证",
        "category": "credential_theft"
    },

    # 文件系统滥用
    {
        "id": "FS_ABUSE_001",
        "pattern": r'(rm\s+-rf|del\s+/[sqf]|Remove-Item\s+-Recurse|shutil\.rmtree)',
        "severity": RiskLevel.CRITICAL,
        "description": "发现破坏性文件操作",
        "category": "filesystem_abuse"
    },
    {
        "id": "FS_ABUSE_002",
        "pattern": r'(\.\./|\.\.\\/|PathTraversal|directory_traversal)',
        "severity": RiskLevel.HIGH,
        "description": "路径穿越尝试",
        "category": "filesystem_abuse"
    },
    {
        "id": "FS_ABUSE_003",
        "pattern": r'(chmod\s+[0-7][0-7][0-7]|chmod\s+777|chmod\s+755)',
        "severity": RiskLevel.MEDIUM,
        "description": "可疑权限修改",
        "category": "filesystem_abuse"
    },

    # 混淆检测
    {
        "id": "OBFUSCATE_001",
        "pattern": r'base64\.(b64encode|b64decode|encode|decode)',
        "severity": RiskLevel.HIGH,
        "description": "Base64 编码/解码操作",
        "category": "obfuscation"
    },
    {
        "id": "OBFUSCATE_002",
        "pattern": r'(chr\(|ord\().*(chr\(|ord\()',
        "severity": RiskLevel.HIGH,
        "description": "字符串拆分编码",
        "category": "obfuscation"
    },
    {
        "id": "OBFUSCATE_003",
        "pattern": r'(zlib|gzip|compress)\s*\(',
        "severity": RiskLevel.MEDIUM,
        "description": "数据压缩操作",
        "category": "obfuscation"
    },
    {
        "id": "OBFUSCATE_004",
        "pattern": r'(marshal|pickle|eval).*loads?',
        "severity": RiskLevel.HIGH,
        "description": "反序列化操作",
        "category": "obfuscation"
    },

    # Bash/Shell 安全风险
    {
        "id": "BASH_RISK_001",
        "pattern": r'\bsource\s+.*\$[{(]',
        "severity": RiskLevel.HIGH,
        "description": "Bash source 加载动态路径（潜在代码注入）",
        "category": "command_injection"
    },
    {
        "id": "BASH_RISK_002",
        "pattern": r'\bcurl\b.*\$\(',
        "severity": RiskLevel.HIGH,
        "description": "Bash curl 结果通过命令替换 $(...) 传递，可能执行不可信内容",
        "category": "command_injection"
    },
    {
        "id": "BASH_RISK_002B",
        "pattern": r'\bcurl\b.*\|\s*(ba)?sh',
        "severity": RiskLevel.CRITICAL,
        "description": "Bash curl 管道到 sh/bash 执行（远程代码执行风险）",
        "category": "command_injection"
    },
    {
        "id": "BASH_RISK_003",
        "pattern": r'\$\([^)]+\)',
        "severity": RiskLevel.LOW,
        "description": "Bash 命令替换 $(...) — 常规语法，需结合上下文判断",
        "category": "command_injection"
    },
    {
        "id": "BASH_RISK_004",
        "pattern": r'(export|set\s+-[aA])\s+\w+=\$\{',
        "severity": RiskLevel.MEDIUM,
        "description": "Bash 导出动态环境变量值",
        "category": "data_exfiltration"
    },

    # 网络攻击
    {
        "id": "NET_ATTACK_001",
        "pattern": r'(socket\.connect|nmap|metasploit|sqlmap|hydra)',
        "severity": RiskLevel.CRITICAL,
        "description": "网络攻击/扫描工具",
        "category": "network_attack"
    },
    {
        "id": "NET_ATTACK_002",
        "pattern": r'(subprocess|os\.system).*(?:ping|scan|port|nmap)',
        "severity": RiskLevel.HIGH,
        "description": "可疑网络扫描行为",
        "category": "network_attack"
    },
    {
        "id": "NET_ATTACK_003",
        "pattern": r'\.onion|\.i2p|tor\s*\)',
        "severity": RiskLevel.HIGH,
        "description": "连接暗网服务",
        "category": "network_attack"
    },

    # 持久化
    {
        "id": "PERSIST_001",
        "pattern": r'(crontab|scheduledTask|launchd|systemd\.timer)',
        "severity": RiskLevel.HIGH,
        "description": "尝试建立持久化机制",
        "category": "persistence"
    },
    {
        "id": "PERSIST_002",
        "pattern": r'(autorun|HKLM\\Software|HKCU\\Software).*(?:Microsoft|Startup|Run)',
        "severity": RiskLevel.CRITICAL,
        "description": "注册表自启动项",
        "category": "persistence"
    },
    {
        "id": "PERSIST_003",
        "pattern": r'(ln\s+-s|mklink|bashrc|profile)\s*.*(?:startup|autorun)',
        "severity": RiskLevel.HIGH,
        "description": "创建自启动链接",
        "category": "persistence"
    },

    # Prompt Injection
    {
        "id": "PROMPT_INJ_001",
        "pattern": r'(ignore\s+previous|disregard\s+instruction|forget\s+all|prompt\s+hijack)',
        "severity": RiskLevel.CRITICAL,
        "description": "Prompt 注入尝试",
        "category": "prompt_injection"
    },
    {
        "id": "PROMPT_INJ_002",
        "pattern": r'(you\s+are\s+now|roleplay|pretend\s+to\s+be|system\s*=|new\s+persona)',
        "severity": RiskLevel.HIGH,
        "description": "角色扮演/身份冒充提示",
        "category": "prompt_injection"
    },
    {
        "id": "PROMPT_INJ_003",
        "pattern": r'(system\s*:|assistant:|human:|ai:).*\{.*\}',
        "severity": RiskLevel.HIGH,
        "description": "隐式提示注入标记",
        "category": "prompt_injection"
    },
    {
        "id": "PROMPT_INJ_004",
        "pattern": r'jailbreak|bypass.*safety|ignore.*policy',
        "severity": RiskLevel.CRITICAL,
        "description": "安全策略绕过尝试",
        "category": "prompt_injection"
    },

    # 权限提升
    {
        "id": "PRIV_ESC_001",
        "pattern": r'(sudo|elevate|runas|chmod\s+[47][0-7][0-7])',
        "severity": RiskLevel.HIGH,
        "description": "权限提升操作",
        "category": "privilege_escalation"
    },
    {
        "id": "PRIV_ESC_002",
        "pattern": r'(win32api|win32con|ctypes).*(?:administrator|system|admin)',
        "severity": RiskLevel.HIGH,
        "description": "Windows 特权操作",
        "category": "privilege_escalation"
    },

    # 可疑域名
    {
        "id": "SUSPICIOUS_001",
        "pattern": r'\.(tk|ml|ga|cf|gq)\s*$',
        "severity": RiskLevel.MEDIUM,
        "description": "可疑免费域名",
        "category": "suspicious_network"
    },
    {
        "id": "SUSPICIOUS_002",
        "pattern": r'(bit\.ly|tinyurl|goo\.gl|ngrok|cloudflare\.app)',
        "severity": RiskLevel.MEDIUM,
        "description": "链接缩短/隧道服务",
        "category": "suspicious_network"
    },
]

# 敏感目录检测
SENSITIVE_DIRECTORIES = [
    ("/.ssh/", RiskLevel.HIGH, "SSH 密钥目录"),
    ("/~/.aws/", RiskLevel.HIGH, "AWS 凭证目录"),
    ("/~/.config/", RiskLevel.MEDIUM, "配置目录"),
    ("/AppData/", RiskLevel.HIGH, "Windows 应用数据"),
    ("/Library/Application Support/", RiskLevel.MEDIUM, "macOS 应用数据"),
    ("/.git/", RiskLevel.MEDIUM, "Git 仓库"),
]


@dataclass
class Finding:
    """检测发现"""
    pattern_id: str
    category: str
    description: str
    severity: RiskLevel
    file_path: str
    line_number: int
    matched_text: str

    def to_dict(self) -> Dict:
        return {
            "id": self.pattern_id,
            "category": self.category,
            "description": self.description,
            "severity": self.severity.name,
            "file": self.file_path,
            "line": self.line_number,
            "match": self.matched_text[:100] + "..." if len(self.matched_text) > 100 else self.matched_text
        }


@dataclass
class ScanResult:
    """扫描结果"""
    skill_name: str = ""
    skill_path: str = ""
    total_files_scanned: int = 0
    total_lines_scanned: int = 0
    findings: List[Finding] = field(default_factory=list)
    risk_distribution: Dict[str, int] = field(default_factory=dict)
    score: float = 100.0  # 默认满分100分
    scan_time: str = ""

    def add_finding(self, finding: Finding):
        self.findings.append(finding)
        risk_name = finding.severity.name
        self.risk_distribution[risk_name] = self.risk_distribution.get(risk_name, 0) + 1


class RegexScanner:
    """正则规则扫描器"""

    def __init__(self, aggressive_mode: bool = False):
        self.patterns = MALICIOUS_PATTERNS
        self.aggressive_mode = aggressive_mode

        # 编译所有正则表达式
        self.compiled_patterns = []
        for p in self.patterns:
            try:
                compiled = re.compile(p["pattern"], re.IGNORECASE | re.MULTILINE)
                self.compiled_patterns.append((compiled, p))
            except re.error as e:
                print(f"Warning: Failed to compile pattern {p['id']}: {e}")

    def scan_file(self, file_path: Path) -> List[Finding]:
        """扫描单个文件"""
        findings = []

        # 判断是否为 Markdown 文件（.md 文件中的代码块示例应降低误报）
        is_markdown = file_path.suffix.lower() == '.md'

        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                lines = content.split('\n')

                # 对 Markdown 文件，追踪代码块范围
                in_code_block = False
                code_block_start = 0

                for line_num, line in enumerate(lines, 1):
                    # 追踪 Markdown 代码块边界
                    if is_markdown and line.strip().startswith('```'):
                        in_code_block = not in_code_block
                        if in_code_block:
                            code_block_start = line_num
                        continue

                    # 检查恶意模式
                    for compiled, pattern_info in self.compiled_patterns:
                        matches = compiled.finditer(line)
                        for match in matches:
                            # Markdown 代码块内的 LOW 级别发现跳过（减少误报）
                            if is_markdown and in_code_block and pattern_info["severity"] == RiskLevel.LOW:
                                continue

                            finding = Finding(
                                pattern_id=pattern_info["id"],
                                category=pattern_info["category"],
                                description=pattern_info["description"],
                                severity=pattern_info["severity"],
                                file_path=str(file_path),
                                line_number=line_num,
                                matched_text=line.strip()
                            )
                            findings.append(finding)

                    # 检查敏感目录（激进模式）
                    if self.aggressive_mode:
                        for dir_path, severity, desc in SENSITIVE_DIRECTORIES:
                            if dir_path in line:
                                finding = Finding(
                                    pattern_id="SENSITIVE_DIR_001",
                                    category="sensitive_directory",
                                    description=desc,
                                    severity=severity,
                                    file_path=str(file_path),
                                    line_number=line_num,
                                    matched_text=line.strip()
                                )
                                findings.append(finding)

        except Exception as e:
            pass  # 静默处理文件读取错误

        return findings

    def scan_directory(self, directory: Path, extensions: List[str] = None) -> ScanResult:
        """扫描整个目录"""
        from datetime import datetime

        if extensions is None:
            extensions = ['.py', '.js', '.ts', '.sh', '.ps1', '.bat', '.cmd', '.md', '.json', '.yaml', '.yml', '.toml', '.rb', '.go', '.rs']

        result = ScanResult(
            skill_name=directory.name,
            skill_path=str(directory),
            scan_time=datetime.now().isoformat()
        )

        # 扫描所有代码文件
        for ext in extensions:
            for file_path in directory.rglob(f'*{ext}'):
                # 跳过特定目录
                skip_dirs = ['__pycache__', 'node_modules', '.git', 'venv', '.venv', 'env']
                if any(sd in str(file_path) for sd in skip_dirs):
                    continue

                result.total_files_scanned += 1
                findings = self.scan_file(file_path)

                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        result.total_lines_scanned += len(f.readlines())
                except:
                    pass

                for finding in findings:
                    result.add_finding(finding)

        # 计算分数
        result.score = self._calculate_score(result)

        return result

    def _calculate_score(self, result: ScanResult) -> float:
        """基于发现计算安全分数（满分100）

        评分逻辑：
        - 无发现: 基础分 100 满分
        - 有发现: 根据风险等级逐级扣分

        扣分标准：
        - CRITICAL: 扣 25 分
        - HIGH: 扣 15 分
        - MEDIUM: 扣 8 分
        - LOW: 扣 3 分
        """
        if not result.findings:
            return 100.0

        deductions = 0
        severity_weights = {
            RiskLevel.CRITICAL: 25,
            RiskLevel.HIGH: 15,
            RiskLevel.MEDIUM: 8,
            RiskLevel.LOW: 3,
            RiskLevel.SAFE: 0
        }

        for finding in result.findings:
            deductions += severity_weights.get(finding.severity, 0)

        return max(0.0, 100.0 - deductions)

    def get_report(self, result: ScanResult) -> str:
        """生成扫描报告"""
        risk_order = ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'SAFE']

        lines = [
            "=" * 64,
            "         SKILL LAYER1 REGEX SECURITY SCAN",
            "=" * 64,
            f"Skill: {result.skill_name}",
            f"Path: {result.skill_path}",
            f"Scanned: {result.scan_time}",
            "-" * 64,
            "",
            "SCAN STATISTICS:",
            f"  Files Scanned: {result.total_files_scanned}",
            f"  Lines Scanned: {result.total_lines_scanned}",
            f"  Total Findings: {len(result.findings)}",
            "",
            "RISK DISTRIBUTION:",
        ]

        for risk in risk_order:
            count = result.risk_distribution.get(risk, 0)
            if count > 0:
                lines.append(f"  {risk}: {count}")

        lines.extend([
            "",
            "=" * 64,
            f"SECURITY SCORE: {result.score:.0f}/100",
            "=" * 64,
        ])

        # 显示关键发现
        if result.findings:
            lines.append("")
            lines.append("KEY FINDINGS:")
            for i, finding in enumerate(result.findings[:10], 1):
                emoji = {"CRITICAL": "🚨", "HIGH": "🔴", "MEDIUM": "🟡", "LOW": "🟢"}.get(
                    finding.severity.name, "⚪")
                lines.append(f"  {i}. {emoji} [{finding.severity.name}] {finding.description}")
                lines.append(f"     → {finding.file_path}:{finding.line_number}")
                lines.append(f"     Code: {finding.matched_text[:80]}...")

        return "\n".join(lines)

    def get_json_report(self, result: ScanResult) -> str:
        """生成 JSON 格式报告"""
        data = {
            "skill": {
                "name": result.skill_name,
                "path": result.skill_path
            },
            "scan_time": result.scan_time,
            "statistics": {
                "files_scanned": result.total_files_scanned,
                "lines_scanned": result.total_lines_scanned,
                "total_findings": len(result.findings)
            },
            "risk_distribution": result.risk_distribution,
            "score": result.score,
            "findings": [f.to_dict() for f in result.findings]
        }
        return json.dumps(data, indent=2, ensure_ascii=False)


# ═══════════════════════════════════════════════════════════════════════════════
# 入口函数
# ═══════════════════════════════════════════════════════════════════════════════

def _normalize_path(path_str: str) -> Path:
    """规范化路径，兼容 Windows/MSYS/Git Bash 路径格式

    Windows 上 Python pathlib 不认识 /c/Users/... 格式，
    需要转换为 C:\\Users\\... 格式
    """
    import re as _re
    p = path_str.replace('\\', '/')
    # 匹配 /c/... 这种 MSYS 风格路径 → C:/...
    m = _re.match(r'^/([a-zA-Z])/(.*)$', p)
    if m:
        drive = m.group(1).upper()
        rest = m.group(2)
        return Path(f'{drive}:\\{rest.replace("/", os.sep)}')
    return Path(path_str)


def scan_skill(path: str, aggressive: bool = False) -> ScanResult:
    """扫描指定路径的 Skill

    Args:
        path: Skill 目录路径
        aggressive: 激进模式（检测更多风险）

    Returns:
        ScanResult: 扫描结果
    """
    scanner = RegexScanner(aggressive_mode=aggressive)
    normalized_path = _normalize_path(path)
    if not normalized_path.exists():
        # 回退：尝试原始路径
        normalized_path = Path(path)
    return scanner.scan_directory(normalized_path)


def main():
    """命令行入口"""
    import argparse

    parser = argparse.ArgumentParser(description="Skill Layer1 Regex Security Scanner")
    parser.add_argument("path", help="Path to skill folder")
    parser.add_argument("--aggressive", "-a", action="store_true", help="Aggressive scanning mode")
    parser.add_argument("--json", "-j", action="store_true", help="Output JSON format")
    parser.add_argument("--output", "-o", help="Output file path")

    args = parser.parse_args()

    result = scan_skill(args.path, aggressive=args.aggressive)

    if args.json:
        scanner = RegexScanner()
        output = scanner.get_json_report(result)
    else:
        scanner = RegexScanner()
        output = scanner.get_report(result)

    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output)
        print(f"Report saved to: {args.output}")
    else:
        print(output)

    # 返回码：0=安全, 1=有风险, 2=高风险
    if result.score < 30:
        exit(2)
    elif result.score < 70:
        exit(1)
    else:
        exit(0)


if __name__ == "__main__":
    main()
