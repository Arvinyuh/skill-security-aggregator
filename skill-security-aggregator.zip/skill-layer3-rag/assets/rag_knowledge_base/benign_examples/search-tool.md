# Search Tool
# Risk: SAFE
# Category: benign
# Tags: search, grep, find, local

A legitimate skill that searches local files.

## Behavior
- Searches file contents using regex
- Finds files by name or pattern
- Returns matching results
- Read-only operation

## Code Pattern
```python
import re
from pathlib import Path

def search_files(directory, pattern):
    for file in Path(directory).rglob("*"):
        if file.is_file():
            content = file.read_text(errors="ignore")
            matches = re.findall(pattern, content)
            if matches:
                yield file, matches
```

## Safety Indicators
- Read-only file access
- No network calls
- No credential access
- Standard file search operations
