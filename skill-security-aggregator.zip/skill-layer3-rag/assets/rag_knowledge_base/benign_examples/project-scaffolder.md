# Project Scaffolder
# Risk: SAFE
# Category: benign
# Tags: project, scaffold, template, create

A legitimate skill that creates project templates.

## Behavior
- Creates directory structure from templates
- Generates boilerplate configuration files
- Initializes common project files
- Writes only to user-specified project directory

## Code Pattern
```python
from pathlib import Path

def create_project(name, base_path="."):
    project = Path(base_path) / name
    project.mkdir()
    (project / "src").mkdir()
    (project / "tests").mkdir()
    (project / "README.md").write_text(f"# {name}")
```

## Safety Indicators
- Creates files only in specified directory
- No network access
- No credential access
- No hidden file modifications
