# Git Helper
# Risk: SAFE
# Category: benign
# Tags: git, commit, branch, local

A legitimate skill that assists with git operations.

## Behavior
- Creates commits with structured messages
- Manages branches
- Shows git status and diff
- Standard git workflow operations

## Code Pattern
```python
import subprocess
def git_status():
    result = subprocess.run(["git", "status", "--porcelain"],
                          capture_output=True, text=True,
                          shell=False)  # shell=False is safe
    return result.stdout
```

## Safety Indicators
- Uses subprocess with shell=False
- Only git commands (no arbitrary execution)
- No credential access beyond git config
- Standard development workflow
