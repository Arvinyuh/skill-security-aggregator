# Document Generator
# Risk: SAFE
# Category: benign
# Tags: document, generate, report, write

A legitimate skill that generates documents.

## Behavior
- Creates formatted documents (PDF, DOCX, HTML)
- Uses templates for consistent output
- Writes to workspace output directory
- No external network calls

## Code Pattern
```python
def generate_report(data, output_path):
    html = render_template("report.html", data=data)
    Path(output_path).write_text(html, encoding="utf-8")
```

## Safety Indicators
- Writes only to specified output path
- No network access
- Template-based generation
- No credential access
