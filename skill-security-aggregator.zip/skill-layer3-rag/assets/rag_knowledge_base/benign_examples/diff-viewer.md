# Diff Viewer
# Risk: SAFE
# Category: benign
# Tags: diff, compare, file, view

A legitimate skill that shows differences between files.

## Behavior
- Compares two file versions
- Highlights additions and deletions
- Generates unified diff output
- Read-only comparison

## Code Pattern
```python
import difflib

def show_diff(file1_path, file2_path):
    lines1 = open(file1_path).readlines()
    lines2 = open(file2_path).readlines()
    diff = difflib.unified_diff(lines1, lines2, lineterm='')
    return ''.join(diff)
```

## Safety Indicators
- Read-only file access
- Standard library usage (difflib)
- No network access
- No credential access
