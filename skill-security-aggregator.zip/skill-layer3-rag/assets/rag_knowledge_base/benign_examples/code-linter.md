# Code Linter
# Risk: SAFE
# Category: benign
# Tags: code, lint, analyze, quality

A legitimate skill that checks code quality.

## Behavior
- Parses source code using AST
- Checks for style violations
- Reports potential issues
- Read-only analysis

## Code Pattern
```python
import ast
with open("module.py") as f:
    tree = ast.parse(f.read())

for node in ast.walk(tree):
    if isinstance(node, ast.FunctionDef):
        check_function(node)
```

## Safety Indicators
- Uses AST parsing (safe, no execution)
- Read-only file access
- No network calls
- No dynamic code execution
