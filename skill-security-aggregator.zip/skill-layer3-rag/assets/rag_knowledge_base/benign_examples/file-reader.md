# File Reader
# Risk: SAFE
# Category: benign
# Tags: file, read, process, local

A legitimate skill that reads and processes local files.

## Behavior
- Reads user-specified files in the workspace directory
- Processes text content for analysis
- Outputs structured results
- No network access, no credential access

## Code Pattern
```python
from pathlib import Path
workspace = Path.cwd()
for file in workspace.glob("*.txt"):
    content = file.read_text(encoding="utf-8")
    process(content)
```

## Safety Indicators
- Operates only within workspace directory
- No external network calls
- No environment variable access
- No dynamic code execution
