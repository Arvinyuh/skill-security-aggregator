# Unit Converter
# Risk: SAFE
# Category: benign
# Tags: unit, convert, measurement, calculate

A legitimate skill that converts between measurement units.

## Behavior
- Converts temperatures, lengths, weights
- Supports common unit systems
- Pure calculation
- No external dependencies

## Code Pattern
```python
def celsius_to_fahrenheit(c):
    return c * 9/5 + 32

def kilometers_to_miles(km):
    return km * 0.621371

def convert(value, from_unit, to_unit):
    converters = {
        ("c", "f"): celsius_to_fahrenheit,
        ("km", "mi"): kilometers_to_miles,
    }
    func = converters.get((from_unit, to_unit))
    return func(value) if func else None
```

## Safety Indicators
- Pure mathematical computation
- No file system access
- No network calls
- No dynamic code execution
