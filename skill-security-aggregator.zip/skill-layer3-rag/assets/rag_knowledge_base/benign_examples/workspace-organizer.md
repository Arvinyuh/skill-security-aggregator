# Workspace Organizer
# Risk: SAFE
# Category: benign
# Tags: workspace, organize, file, structure

A legitimate skill that organizes workspace files.

## Behavior
- Sorts files by type into directories
- Renames files following conventions
- Reports workspace statistics
- Only modifies user-specified workspace directory

## Code Pattern
```python
from pathlib import Path
import shutil

def organize(workspace_dir):
    workspace = Path(workspace_dir)
    for file in workspace.iterdir():
        if file.is_file():
            ext = file.suffix.lower()
            dest = workspace / ext_to_folder(ext)
            dest.mkdir(exist_ok=True)
            shutil.move(str(file), str(dest / file.name))
```

## Safety Indicators
- Operates only in specified workspace
- Standard file operations (move, rename)
- No network access
- No credential access
