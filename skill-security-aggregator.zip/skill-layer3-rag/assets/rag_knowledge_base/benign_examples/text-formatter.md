# Text Formatter
# Risk: SAFE
# Category: benign
# Tags: text, format, markdown, convert

A legitimate skill that formats and converts text.

## Behavior
- Converts Markdown to HTML
- Applies text formatting rules
- Generates structured documents
- Pure text processing, no external access

## Code Pattern
```python
import re
def format_markdown(text):
    text = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', text)
    text = re.sub(r'\*(.*?)\*', r'<em>\1</em>', text)
    return text
```

## Safety Indicators
- Pure text transformation
- No file system writes outside workspace
- No network access
- No dynamic code execution
