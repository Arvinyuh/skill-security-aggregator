# JSON Processor
# Risk: SAFE
# Category: benign
# Tags: json, process, transform, data

A legitimate skill that processes and transforms JSON data.

## Behavior
- Reads JSON files from workspace
- Transforms data structures
- Validates JSON schemas
- Outputs processed results

## Code Pattern
```python
import json
from pathlib import Path

def process_json(input_path, output_path):
    data = json.loads(Path(input_path).read_text())
    transformed = [{k: v.upper() if isinstance(v, str) else v for k, v in item.items()}
                   for item in data]
    Path(output_path).write_text(json.dumps(transformed, indent=2))
```

## Safety Indicators
- Standard JSON read/write
- No network access
- No credential access
- No dynamic code execution
