# Markdown Renderer
# Risk: SAFE
# Category: benign
# Tags: markdown, render, preview, html

A legitimate skill that renders Markdown to HTML for preview.

## Behavior
- Parses Markdown syntax
- Generates HTML with inline styles
- Creates preview output
- Pure text transformation

## Code Pattern
```python
import re

def render_markdown(md_text):
    # Headers
    md_text = re.sub(r'^### (.+)$', r'<h3>\1</h3>', md_text, flags=re.MULTILINE)
    md_text = re.sub(r'^## (.+)$', r'<h2>\1</h2>', md_text, flags=re.MULTILINE)
    # Paragraphs
    md_text = re.sub(r'\n\n', '</p><p>', md_text)
    return f'<div><p>{md_text}</p></div>'
```

## Safety Indicators
- Pure text transformation
- No file writes
- No network access
- No dynamic code execution
