# Data Analyzer
# Risk: SAFE
# Category: benign
# Tags: data, analyze, statistics, local

A legitimate skill that performs statistical analysis on local data.

## Behavior
- Reads CSV/JSON data files from workspace
- Computes statistical summaries
- Generates visualization data
- No external API calls

## Code Pattern
```python
import csv
from collections import Counter

with open("data.csv") as f:
    reader = csv.DictReader(f)
    data = list(reader)

summary = Counter(row["category"] for row in data)
```

## Safety Indicators
- Reads only specified data files
- No network requests
- No credential access
- Computation-only operations
