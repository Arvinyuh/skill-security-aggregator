# Version Checker
# Risk: SAFE
# Category: benign
# Tags: version, check, compatibility, local

A legitimate skill that checks software versions.

## Behavior
- Reads local version files
- Compares against compatibility matrix
- Reports version status
- No auto-update functionality

## Code Pattern
```python
import json
from pathlib import Path

def check_versions():
    with open("package.json") as f:
        pkg = json.load(f)
    return {dep: ver for dep, ver in pkg.get("dependencies", {}).items()}
```

## Safety Indicators
- Reads only project configuration files
- No network calls for updates
- No auto-installation
- Read-only analysis
