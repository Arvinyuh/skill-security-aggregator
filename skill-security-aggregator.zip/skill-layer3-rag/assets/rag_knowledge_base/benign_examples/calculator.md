# Calculator
# Risk: SAFE
# Category: benign
# Tags: calculate, math, convert, unit

A legitimate skill that performs calculations.

## Behavior
- Evaluates mathematical expressions
- Converts units
- Computes financial calculations
- Pure computation, no side effects

## Code Pattern
```python
def calculate(expression):
    # Safe evaluation using ast.literal_eval or simple parser
    import ast
    tree = ast.parse(expression, mode='eval')
    return eval(compile(tree, '<string>', 'eval'),
                {"__builtins__": {}},
                {"abs": abs, "round": round, "max": max, "min": min})
```

## Safety Indicators
- Restricted evaluation scope
- No file system access
- No network calls
- No dynamic code execution from external input
