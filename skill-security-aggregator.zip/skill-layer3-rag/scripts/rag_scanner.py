"""
Skill Layer3: RAG Knowledge Base Security Scanner
基于 TF-IDF 和余弦相似度的知识库扫描
满分100分
"""

import os
import re
import math
import json
import sys
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional, Set
from collections import Counter, defaultdict
from datetime import datetime
import hashlib


# ═══════════════════════════════════════════════════════════════════════════════
# TF-IDF 向量化器
# ═══════════════════════════════════════════════════════════════════════════════

class TFIDFVectorizer:
    """TF-IDF 文本向量化器"""

    def __init__(self):
        self.vocabulary: Dict[str, int] = {}
        self.idf: Dict[str, float] = {}
        self.doc_count: int = 0

    def _tokenize(self, text: str) -> List[str]:
        """分词"""
        text = text.lower()
        text = re.sub(r'[^a-z0-9\s]', ' ', text)
        tokens = text.split()
        tokens = [t for t in tokens if len(t) >= 2]
        return tokens

    def _compute_tf(self, tokens: List[str]) -> Dict[str, float]:
        """计算词频"""
        counter = Counter(tokens)
        total = len(tokens) if tokens else 1
        return {word: count / total for word, count in counter.items()}

    def _compute_idf(self, corpus: List[List[str]]):
        """计算逆文档频率"""
        self.doc_count = len(corpus)
        df = defaultdict(int)

        for tokens in corpus:
            unique_tokens = set(tokens)
            for token in unique_tokens:
                df[token] += 1

        for token, doc_freq in df.items():
            self.idf[token] = math.log(self.doc_count / (1 + doc_freq)) + 1

    def fit(self, documents: List[str]):
        """训练向量化器"""
        tokenized_docs = [self._tokenize(doc) for doc in documents]
        all_tokens = set()
        for tokens in tokenized_docs:
            all_tokens.update(tokens)

        self.vocabulary = {token: idx for idx, token in enumerate(sorted(all_tokens))}
        self._compute_idf(tokenized_docs)
        return self

    def transform(self, document: str) -> Dict[str, float]:
        """转换文档为 TF-IDF 向量"""
        tokens = self._tokenize(document)
        tf = self._compute_tf(tokens)
        tfidf = {}
        for token, tf_val in tf.items():
            if token in self.vocabulary:
                tfidf[token] = tf_val * self.idf.get(token, 1.0)
        return tfidf

    def fit_transform(self, documents: List[str]) -> List[Dict[str, float]]:
        """训练并转换"""
        self.fit(documents)
        return [self.transform(doc) for doc in documents]


def cosine_similarity(vec1: Dict[str, float], vec2: Dict[str, float]) -> float:
    """计算两个向量的余弦相似度"""
    common_words = set(vec1.keys()) & set(vec2.keys())
    if not common_words:
        return 0.0

    dot_product = sum(vec1[word] * vec2[word] for word in common_words)
    mag1 = math.sqrt(sum(v ** 2 for v in vec1.values()))
    mag2 = math.sqrt(sum(v ** 2 for v in vec2.values()))

    if mag1 == 0 or mag2 == 0:
        return 0.0

    return dot_product / (mag1 * mag2)


# ═══════════════════════════════════════════════════════════════════════════════
# 知识库条目
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class KnowledgeEntry:
    """知识库条目"""
    entry_id: str
    category: str  # malware, benign
    severity: str  # critical, high, medium, low, safe
    title: str
    content: str
    file_path: str
    tags: List[str] = field(default_factory=list)
    similarity: float = 0.0  # 匹配时的相似度

    def to_dict(self) -> Dict:
        return {
            "id": self.entry_id,
            "category": self.category,
            "severity": self.severity,
            "title": self.title,
            "content_preview": self.content[:100] + "..." if len(self.content) > 100 else self.content,
            "file": self.file_path,
            "tags": self.tags,
            "similarity": self.similarity
        }


@dataclass
class RAGScanResult:
    """RAG 扫描结果"""
    skill_name: str = ""
    skill_path: str = ""
    score: float = 100.0  # 默认满分100
    total_entries: int = 0
    matches: List[KnowledgeEntry] = field(default_factory=list)
    malware_matches: int = 0
    benign_matches: int = 0
    scan_time: str = ""

    def to_dict(self) -> Dict:
        return {
            "skill_name": self.skill_name,
            "skill_path": self.skill_path,
            "score": self.score,
            "total_entries": self.total_entries,
            "matches": [m.to_dict() for m in self.matches],
            "malware_matches": self.malware_matches,
            "benign_matches": self.benign_matches,
            "scan_time": self.scan_time
        }


# ═══════════════════════════════════════════════════════════════════════════════
# RAG 知识库
# ═══════════════════════════════════════════════════════════════════════════════

class RAGKnowledgeBase:
    """RAG 知识库扫描器"""

    def __init__(self, base_path: Optional[Path] = None):
        self.base_path = base_path or Path(__file__).parent.parent / "assets" / "rag_knowledge_base"
        self.entries: List[KnowledgeEntry] = []
        self.vectorizer = TFIDFVectorizer()
        self.vectors: List[Dict[str, float]] = []

    def load_from_directory(self):
        """从目录加载知识库"""
        if not self.base_path.exists():
            print(f"Warning: Knowledge base path not found: {self.base_path}", file=sys.stderr)
            return

        malware_dir = self.base_path / "malware_examples"
        benign_dir = self.base_path / "benign_examples"

        if malware_dir.exists():
            self._load_examples(malware_dir, "malware")

        if benign_dir.exists():
            self._load_examples(benign_dir, "benign")

        self._build_index()
        print(f"Loaded {len(self.entries)} knowledge base entries", file=sys.stderr)

    def _load_examples(self, directory: Path, category: str):
        """加载示例文件"""
        severity_map = {
            "critical_malware": "critical",
            "high_malware": "high",
            "medium_malware": "medium",
            "low_malware": "low",
            "benign": "safe"
        }

        for file_path in directory.rglob("*"):
            if file_path.is_file() and file_path.suffix in ['.py', '.js', '.ts', '.md', '.txt', '.json']:
                try:
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()

                    severity = "medium"
                    for folder_name, sev in severity_map.items():
                        if folder_name in str(file_path):
                            severity = sev
                            break

                    entry = KnowledgeEntry(
                        entry_id=self._generate_id(content),
                        category=category,
                        severity=severity,
                        title=file_path.stem,
                        content=content,
                        file_path=str(file_path),
                        tags=self._extract_tags(content)
                    )
                    self.entries.append(entry)

                except Exception as e:
                    print(f"Error loading {file_path}: {e}", file=sys.stderr)

    def _generate_id(self, content: str) -> str:
        """生成唯一ID"""
        return hashlib.md5(content[:500].encode()).hexdigest()[:12]

    def _extract_tags(self, content: str) -> List[str]:
        """提取标签"""
        keywords = [
            "credential", "network", "file", "command", "crypto",
            "injection", "obfuscation", "persistence", "exfiltration",
            "reconnaissance", "shell", "keylogger", "webhook",
            "process", "memory", "system", "api", "http", "data"
        ]

        content_lower = content.lower()
        return [kw for kw in keywords if kw in content_lower][:5]

    def _build_index(self):
        """构建搜索索引"""
        if not self.entries:
            return

        documents = [entry.content for entry in self.entries]
        self.vectors = self.vectorizer.fit_transform(documents)

    def retrieve(self, query: str, top_k: int = 5, min_similarity: float = 0.1) -> List[KnowledgeEntry]:
        """检索相关条目"""
        if not self.entries or not self.vectors:
            return []

        query_vector = self.vectorizer.transform(query)
        similarities = []

        for idx, entry in enumerate(self.entries):
            sim = cosine_similarity(query_vector, self.vectors[idx])
            if sim >= min_similarity:
                entry.similarity = sim
                similarities.append((entry, sim))

        similarities.sort(key=lambda x: x[1], reverse=True)
        return [entry for entry, _ in similarities[:top_k]]

    def calculate_score(self, matches: List[KnowledgeEntry]) -> float:
        """计算 RAG 扫描分数（满分100）

        评分逻辑：
        - 无匹配: +50分（无法判断时偏向安全）
        - 恶意匹配: -25分/个
        - 良性匹配: +10分/个
        """
        if not matches:
            return 100.0

        score = 100.0

        malware_penalty = 0
        benign_bonus = 0

        for entry in matches:
            if entry.category == "malware":
                severity_weights = {
                    "critical": 30,
                    "high": 25,
                    "medium": 15,
                    "low": 10
                }
                penalty = severity_weights.get(entry.severity, 20) * entry.similarity
                malware_penalty += penalty
            elif entry.category == "benign":
                benign_bonus += entry.similarity * 10

        score = score - malware_penalty + benign_bonus
        return max(0.0, min(100.0, score))

    def get_stats(self) -> Dict:
        """获取统计信息"""
        categories = Counter(e.category for e in self.entries)
        severities = Counter(e.severity for e in self.entries)

        return {
            "total_entries": len(self.entries),
            "by_category": dict(categories),
            "by_severity": dict(severities)
        }


# ═══════════════════════════════════════════════════════════════════════════════
# 入口函数
# ═══════════════════════════════════════════════════════════════════════════════

def _normalize_path(path_str: str) -> Path:
    """规范化路径，兼容 Windows/MSYS/Git Bash 路径格式"""
    import re as _re
    p = path_str.replace('\\', '/')
    m = _re.match(r'^/([a-zA-Z])/(.*)$', p)
    if m:
        drive = m.group(1).upper()
        rest = m.group(2)
        return Path(f'{drive}:\\{rest.replace("/", os.sep)}')
    return Path(path_str)


def scan_skill(path: str, top_k: int = 5, min_similarity: float = 0.1) -> RAGScanResult:
    """扫描 Skill

    Args:
        path: Skill 目录路径
        top_k: 返回前 k 个匹配
        min_similarity: 最小相似度阈值

    Returns:
        RAGScanResult: 扫描结果
    """
    from datetime import datetime

    # 创建 RAG 引擎
    base_path = Path(__file__).parent.parent / "assets" / "rag_knowledge_base"
    engine = RAGKnowledgeBase(base_path)
    engine.load_from_directory()

    # 构建查询内容（兼容 Windows MSYS 路径）
    skill_path = _normalize_path(path)
    if not skill_path.exists():
        skill_path = Path(path)
    queries = []

    # 从 SKILL.md 提取内容
    skill_md = skill_path / "SKILL.md"
    if skill_md.exists():
        with open(skill_md, 'r', encoding='utf-8', errors='ignore') as f:
            queries.append(f.read()[:2000])

    # 从根目录提取脚本文件（.sh, .py, .ps1, .bat 等）
    script_extensions = ['.sh', '.py', '.ps1', '.bat', '.cmd', '.rb', '.js']
    for ext in script_extensions:
        for script in skill_path.glob(f'*{ext}'):
            try:
                with open(script, 'r', encoding='utf-8', errors='ignore') as f:
                    queries.append(f.read()[:2000])
            except:
                pass

    # 从 scripts/ 子目录提取代码
    scripts_dir = skill_path / "scripts"
    if scripts_dir.exists():
        for script in scripts_dir.glob("*"):
            if script.is_file() and script.suffix in script_extensions + ['.md', '.json']:
                try:
                    with open(script, 'r', encoding='utf-8', errors='ignore') as f:
                        queries.append(f.read()[:2000])
                except:
                    pass

    query = " ".join(queries)

    # 检索匹配
    matches = engine.retrieve(query, top_k=top_k, min_similarity=min_similarity)

    # 计算分数
    score = engine.calculate_score(matches)

    # 统计匹配类型
    malware_matches = sum(1 for m in matches if m.category == "malware")
    benign_matches = sum(1 for m in matches if m.category == "benign")

    return RAGScanResult(
        skill_name=skill_path.name,
        skill_path=str(skill_path),
        score=score,
        total_entries=len(engine.entries),
        matches=matches,
        malware_matches=malware_matches,
        benign_matches=benign_matches,
        scan_time=datetime.now().isoformat()
    )


class RAGScanner:
    """RAG 扫描器封装类"""

    def __init__(self, base_path: Optional[Path] = None):
        self.base_path = base_path or Path(__file__).parent.parent / "assets" / "rag_knowledge_base"
        self.engine = RAGKnowledgeBase(self.base_path)
        self.engine.load_from_directory()

    def scan(self, skill_path: Path, top_k: int = 5, min_similarity: float = 0.1) -> RAGScanResult:
        """扫描 Skill"""
        return scan_skill(str(skill_path), top_k, min_similarity)

    def get_report(self, result: RAGScanResult) -> str:
        """生成报告"""
        lines = [
            "=" * 64,
            "         SKILL RAG KNOWLEDGE BASE SCAN",
            "=" * 64,
            f"Skill: {result.skill_name}",
            f"Path: {result.skill_path}",
            f"Scanned: {result.scan_time}",
            f"Knowledge Base Entries: {result.total_entries}",
            "-" * 64,
            "",
        ]

        if result.matches:
            lines.append("TOP MATCHES:")
            for entry in result.matches:
                emoji = "🚨" if entry.category == "malware" else "✅"
                category = entry.category.upper()
                lines.append(f"  {emoji} {entry.title} ({category}, similarity: {entry.similarity:.2f})")
                lines.append(f"     Severity: {entry.severity.upper()}")
                lines.append(f"     Preview: {entry.content[:80]}...")
                lines.append("")
        else:
            lines.append("NO MATCHES FOUND")
            lines.append("Skill content does not match any known patterns.")
            lines.append("")

        lines.extend([
            "=" * 64,
            f"SECURITY SCORE: {result.score:.0f}/100",
            f"MATCHES: {result.malware_matches} malware, {result.benign_matches} benign",
            "=" * 64,
        ])

        return "\n".join(lines)

    def get_json_report(self, result: RAGScanResult) -> str:
        """生成 JSON 报告"""
        return json.dumps(result.to_dict(), indent=2, ensure_ascii=False)


def main():
    """命令行入口"""
    import argparse

    parser = argparse.ArgumentParser(description="Skill Layer3 RAG Knowledge Base Scanner")
    parser.add_argument("path", help="Path to skill folder")
    parser.add_argument("--top-k", type=int, default=5, help="Number of top matches to return")
    parser.add_argument("--min-similarity", type=float, default=0.1, help="Minimum similarity threshold")
    parser.add_argument("--json", "-j", action="store_true", help="Output JSON format")
    parser.add_argument("--output", "-o", help="Output file path")

    args = parser.parse_args()

    result = scan_skill(args.path, top_k=args.top_k, min_similarity=args.min_similarity)

    scanner = RAGScanner()
    if args.json:
        output = scanner.get_json_report(result)
    else:
        output = scanner.get_report(result)

    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output)
        print(f"Report saved to: {args.output}", file=sys.stderr)
    else:
        print(output)

    # 返回码
    if result.score < 30:
        exit(2)
    elif result.score < 70:
        exit(1)
    else:
        exit(0)


if __name__ == "__main__":
    main()
