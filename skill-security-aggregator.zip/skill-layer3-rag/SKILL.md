# Skill Layer3 - RAG Knowledge Base Security Scanner

基于检索增强生成（RAG）的安全知识库扫描工具。

## 核心特点

- **知识库驱动**：基于已知恶意/良性样本进行匹配
- **TF-IDF 向量化**：使用 TF-IDF 算法进行语义相似度计算
- **满分100分**：独立的评分体系
- **可扩展**：支持添加新的恶意/良性样本

## 知识库结构

```
assets/rag_knowledge_base/
├── malware_examples/
│   ├── critical_malware/    # 严重恶意样本
│   ├── high_malware/        # 高风险样本
│   ├── medium_malware/      # 中等风险样本
│   └── low_malware/         # 低风险样本
└── benign_examples/         # 良性参考样本
```

## 评分规则（满分100）

| 匹配类型 | 分数调整 |
|----------|----------|
| 恶意样本匹配 | -25分/个 |
| 良性样本匹配 | +10分/个 |
| 无匹配 | +50分（无法判断时偏向安全） |

## 使用方法

### 命令行

```bash
python scripts/rag_scanner.py /path/to/skill
python scripts/rag_scanner.py /path/to/skill --top-k 10
```

### Python API

```python
from scripts.rag_scanner import scan_skill, RAGScanResult

# 扫描 Skill
result: RAGScanResult = scan_skill("/path/to/skill")

# 访问结果
print(f"分数: {result.score}/100")
print(f"匹配数: {len(result.matches)}")
for match in result.matches:
    print(f"  [{match.severity}] {match.title} (相似度: {match.similarity:.2f})")
```

## 输出示例

```
SKILL RAG KNOWLEDGE BASE SCAN
═══════════════════════════════════════════════════════════════
Skill: example-skill
Knowledge Base Entries: 50
───────────────────────────────────────────────────────────────
TOP MATCHES:
  📚 credential-harvester.py (malware, similarity: 0.85)
     相似: 数据外泄到外部服务器

  📚 network-monitor.py (malware, similarity: 0.72)
     相似: 网络流量监控

  ✅ clean-file-processor.py (benign, similarity: 0.65)
     相似: 标准文件处理流程
───────────────────────────────────────────────────────────────
SECURITY SCORE: 60/100
═══════════════════════════════════════════════════════════════
```

## 添加新样本

### 添加恶意样本

```bash
# 创建目录结构
mkdir -p assets/rag_knowledge_base/malware_examples/critical_malware

# 添加样本文件
echo "# Credential Harvester
# 功能: 收集系统凭证并发送到外部服务器
# 风险: CRITICAL
..." > assets/rag_knowledge_base/malware_examples/critical_malware/credential-harvester.md
```

### 添加良性样本

```bash
mkdir -p assets/rag_knowledge_base/benign_examples

echo "# File Processor
# 功能: 读取并处理本地文件
# 风险: SAFE
..." > assets/rag_knowledge_base/benign_examples/file-processor.md
```

## 适用场景

- 补充 Layer1/Layer2 的检测能力
- 识别已知攻击模式
- 验证 Skill 是否属于可信类型
- 自动化安全合规检测
